<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="lt">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Užapvalinimas / Nusklembimas (Paketinis)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Pasirinktų objektų paketinis užapvalinimo ir nusklembimo skydelis</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Užapvalinimo / nusklembimo įrankis</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Įrankis užapvalinimams ir nusklembimams kurti vektorinėse geometrijose</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Užapvalinimas ir nusklembimas</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Įspėjimas</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktyvus sluoksnis turi būti vektorinis sluoksnis redagavimo režime.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informacija</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Nėra pasirinktų objektų apdorojimui.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Paketinis užapvalinimas</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Paketinis nusklembimas</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Sėkmė</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Apdorota {} objektų.</translation>
        </message>
        <message>
            <source>Пакетне відновлення кутів</source>
            <translation>Paketinis kampų atkūrimas</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Užapvalinimo / nusklembimo nustatymai</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Operacijos režimas</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Užapvalinimas (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Nusklembimas (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Užapvalinimo parametrai</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>vnt.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Spindulys (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Lanko segmentų skaičius:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Nusklembimo parametrai</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Atstumas 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Atstumas 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Vienodi atstumai (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Taikyti pasirinktiems objektams</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Taikyti užapvalinimą arba nusklembimą visoms pasirinktų objektų viršūnėms</translation>
        </message>
        <message>
            <source>Відновлення кутів</source>
            <translation>Atkurti kampus</translation>
        </message>
        <message>
            <source>Видалити скруглення та фаски, відновивши гострі кути</source>
            <translation>Pašalinti užapvalinimus ir nusklemSingleimus, atkuriant aštrius kampus</translation>
        </message>
        <message>
            <source>Параметри відновлення кутів</source>
            <translation>Kampų atkūrimo parametrai</translation>
        </message>
        <message>
            <source>Видаляє всі виявлені скруглення та фаски, відновлюючи вихідні гострі кути для всіх вершин виділених об'єктів.</source>
            <translation>Pašalina visus aptiktus užapvalinimus ir nusklemSingleimus, atkuriant pradinius aštrius kampus visoms pasirinktų objektų viršūnėms.</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Užapvalinimas</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Nusklembimas</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Spindulys</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Užrakinti / atrakinti spindulį</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Užapvalinimo segmentai</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Atstumas 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Užrakinti / atrakinti atstumą 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Atstumas 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Užrakinti / atrakinti atstumą 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Atstumai susieti (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Atstumai nepriklausomi (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Restore</source>
            <translation>Atkurti</translation>
        </message>
        <message>
            <source>Клікніть на вершину для відновлення гострого кута.</source>
            <translation>Spustelėkite viršūnę, kad atkurtumėte aštrų kampą.</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Viršūnės užapvalinimas</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Viršūnės nusklembimas</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Atkurti kampą</translation>
        </message>
    </context>
</TS>
