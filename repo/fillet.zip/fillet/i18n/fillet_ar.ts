<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="ar">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>تسطيح / شطب (مجموعة)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>لوحة التسطيح والشطب المجمعة للعناصر المحددة</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>أداة التسطيح / الشطب</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>أداة لإنشاء شرائح وشطب على الأشكال الهندسية الشعاعية</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>تسطيح وشطب</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>تحذير</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>يجب أن تكون الطبقة النشطة طبقة متجهية في وضع التحرير.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>معلومات</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>لا توجد معالم محددة للمعالجة.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>تسطيح دفعة</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>شطب دفعة</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>نجاح</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>تمت معالجة {} معلم (معالم).</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>استعادة الزوايا (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>أداة استعادة الزوايا الحادة (تزيل الاستدارات والشطفات)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>إعدادات التسطيح / الشطب</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>وضع العملية</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>تسطيح (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>شطب (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>معلمات التسطيح</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>وحدة</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>نصف القطر (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>عدد مقاطع القوس:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>معلمات الشطب</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>المسافة 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>المسافة 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>مسافات متساوية (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>تطبيق على المعالم المحددة</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>تطبيق التسطيح أو الشطب على جميع رؤوس المعالم المحددة</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>تسطيح</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>شطب</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>نصف القطر</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>قفل / إلغاء قفل نصف القطر</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>مقاطع التسطيح</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>المسافة 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>قفل / إلغاء قفل المسافة 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>المسافة 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>قفل / إلغاء قفل المسافة 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>المسافات مرتبطة (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>المسافات منفصلة (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>تسطيح الرأس</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>شطب الرأس</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>استعادة الزاوية</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>استعادة الزاوية الحادة</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>الخطوة 1: انقر فوق الحافة الأولى للزاوية</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>الخطوة 2: انقر فوق الحافة المجاورة الثانية لإعادة بناء الزاوية</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>زر الفأرة الأيمن أو Esc — إلغاء</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>إلغاء</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>استعادة الزاوية</translation>
        </message>
    </context>
</TS>
