<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="hu">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Lekerekítés / Letörés (Kötegelt)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Kötegelt lekerekítés és letörés panel a kijelölt elemekhez</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Lekerekítés / Letörés eszköz</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Eszköz vektor geometriák lekerekítéséhez és letöréséhez</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Lekerekítés és letörés</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Figyelmeztetés</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Az aktív rétegnek szerkesztési módban lévő vektoros rétegnek kell lennie.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Információ</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Nincsenek feldolgozandó kijelölt elemek.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Kötegelt lekerekítés</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Kötegelt letörés</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Siker</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>{} elem feldolgozva.</translation>
        </message>
        <message>
            <source>Пакетне відновлення кутів</source>
            <translation>Sarkok kötegelt visszaállítása</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Lekerekítés / Letörés beállítások</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Műveleti mód</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Lekerekítés (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Letörés (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Lekerekítési paraméterek</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>egys.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Sugár (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Körív szegmensek száma:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Letörési paraméterek</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Távolság 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Távolság 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Azonos távolságok (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Alkalmazás a kijelölt elemekre</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Lekerekítés vagy letörés alkalmazása a kijelölt elemek minden töréspontjára</translation>
        </message>
        <message>
            <source>Відновлення кутів</source>
            <translation>Sarkok visszaállítása</translation>
        </message>
        <message>
            <source>Видалити скруглення та фаски, відновивши гострі кути</source>
            <translation>Lekerekítések és letörések eltávolítása, éles sarkok visszaállítása</translation>
        </message>
        <message>
            <source>Параметри відновлення кутів</source>
            <translation>Sarok-visszaállítási paraméterek</translation>
        </message>
        <message>
            <source>Видаляє всі виявлені скруглення та фаски, відновлюючи вихідні гострі кути для всіх вершин виділених об'єктів.</source>
            <translation>Eltávolítja az összes észlelt lekerekítést és letörést, visszaállítva az eredeti éles sarkokat a kijelölt elemek minden töréspontjához.</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Lekerekítés</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Letörés</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Sugár</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Sugár zárolása / feloldása</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Lekerekítés szegmensek</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Távolság 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Távolság 1 zárolása / feloldása</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Távolság 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Távolság 2 zárolása / feloldása</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Távolságok összekapcsolva (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Különálló távolságok (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Restore</source>
            <translation>Visszaállítás</translation>
        </message>
        <message>
            <source>Клікніть на вершину для відновлення гострого кута.</source>
            <translation>Kattintson egy töréspontra az éles sarok visszaállításához.</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Töréspont lekerekítése</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Töréspont letörése</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Sarok visszaállítása</translation>
        </message>
    </context>
</TS>
