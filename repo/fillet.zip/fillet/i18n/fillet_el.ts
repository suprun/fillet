<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="el">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Στρογγυλοποίηση / Λοξότμηση (Μαζική επεξεργασία)</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Εργαλείο Στρογγυλοποίησης / Λοξότμησης</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Εργαλείο για δημιουργία στρογγυλοποιήσεων και λοξοτμήσεων σε διανυσματικές γεωμετρίες</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Στρογγυλοποίηση &amp; Λοξότμηση</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Προειδοποίηση</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Το ενεργό επίπεδο πρέπει να είναι διανυσματικό επίπεδο σε λειτουργία επεξεργασίας.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Πληροφορίες</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Δεν υπάρχουν επιλεγμένα στοιχεία για επεξεργασία.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Μαζική στρογγυλοποίηση</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Μαζική λοξότμηση</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Επιτυχία</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Επεξεργάστηκαν {} στοιχεία.</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Ρυθμίσεις Στρογγυλοποίησης / Λοξότμησης</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Λειτουργία λειτουργίας</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Στρογγυλοποίηση (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Λοξότμηση (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Παράμετροι στρογγυλοποίησης</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>μον.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Ακτίνα (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Αριθμός τμημάτων τόξου:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Παράμετροι λοξότμησης</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Απόσταση 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Απόσταση 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Ίσες αποστάσεις (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Εφαρμογή στα επιλεγμένα στοιχεία</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Εφαρμογή στρογγυλοποίησης ή λοξότμησης σε όλες τις κορυφές των επιλεγμένων στοιχείων</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Στρογγυλοποίηση</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Λοξότμηση</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Ακτίνα</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Κλείδωμα / ξεκλείδωμα ακτίνας</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Τμήματα στρογγυλοποίησης</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Απόσταση 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Κλείδωμα / ξεκλείδωμα απόστασης 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Απόσταση 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Κλείδωμα / ξεκλείδωμα απόστασης 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Συνδεδεμένες αποστάσεις (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Ανεξάρτητες αποστάσεις (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Στρογγυλοποίηση κορυφής</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Λοξότμηση κορυφής</translation>
        </message>
    </context>
</TS>
