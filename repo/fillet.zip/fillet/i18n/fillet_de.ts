<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="de">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Stapelverarbeitung)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panel für Stapel-Abrundung (Fillet) und Fase (Chamfer) für ausgewählte Objekte</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Werkzeug</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Werkzeug zum Erstellen von Abrundungen (Fillet) und Fasen (Chamfer)</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Warnung</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Der aktive Layer muss ein Vektorlayer im Bearbeitungsmodus sein.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Info</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Keine ausgewählten Objekte zur Verarbeitung.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Stapel-Abrundung</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Stapel-Fase</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Erfolg</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>{} Objekt(e) verarbeitet.</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Ecken wiederherstellen (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Werkzeug zur Wiederherstellung scharfer Ecken (entfernt Abrundungen und Fasen)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Einstellungen</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Betriebsmodus</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Abrundung (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Fase (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Abrundungsparameter</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>Einh.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Radius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Anzahl Bogensegmente:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Fasenparameter</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Abstand 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Abstand 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Gleiche Abstände (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Auf ausgewählte Objekte anwenden</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Abrundung oder Fase auf alle Stützpunkte der ausgewählten Objekte anwenden</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Radius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Radius sperren / entsperren</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Bogensegmente</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Abstand 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Abstand 1 sperren / entsperren</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Abstand 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Abstand 2 sperren / entsperren</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Abstände verknüpft (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Abstände getrennt (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Stützpunkt-Abrundung</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Stützpunkt-Fase</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Ecke wiederherstellen</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>Scharfe Ecke wiederherstellen</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>Schritt 1: Klicken Sie auf die erste Kante der Ecke</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>Schritt 2: Klicken Sie auf die benachbarte zweite Kante, um die Ecke zu rekonstruieren</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>RMB oder Esc — Abbrechen</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>Abbrechen</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>Ecke wiederherstellen</translation>
        </message>
    </context>
</TS>
