<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="hi">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>फिलेट / चैम्फर (बैच)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>चयनित सुविधाओं के लिए बैच फिलेट और चैम्फर पैनल</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>फिलेट / चैम्फर टूल</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>वेक्टर ज्यामिति पर फिलेट और चैम्फर बनाने का उपकरण</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>फिलेट और चैम्फर</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>चेतावनी</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>सक्रिय परत संपादन मोड में एक वेक्टर परत होनी चाहिए।</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>जानकारी</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>प्रक्रिया के लिए कोई चयनित फ़ीचर नहीं है।</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>बैच फिलेट</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>बैच चैम्फर</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>सफलता</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>{} फ़ीचर संसाधित किए गए।</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. पहला कोना किनारा निर्दिष्ट करें</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. आसन्न दूसरा किनारा निर्दिष्ट करें</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>कोना पुनर्स्थापन (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>नुकीले कोनों को पुनर्स्थापित करने के लिए इंटरैक्टिव टूल (फिलेट और चैम्फर हटाता है)</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. घूर्णन केंद्र (धुरी) निर्दिष्ट करें</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. संदर्भ आधार रेखा निर्दिष्ट करें</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. लक्ष्य घूर्णन कोण निर्दिष्ट करें</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>सीएडी घुमाएँ</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>धुरी केंद्र चयन के साथ ज्यामिति के लिए इंटरैक्टिव सीएडी रोटेशन टूल</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>कोण:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>कोण लॉक करें / इंटरैक्टिव रोटेशन</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>कोण चरण:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>मुक्त</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>प्रतिलिपि रखें</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>मूल को बरकरार रखते हुए चयनित सुविधाओं की एक घुमाई गई प्रतिलिपि बनाता है</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>बैच प्रसंस्करण के लिए, परत संपादन योग्य होनी चाहिए और इसमें चयनित सुविधाएं होनी चाहिए</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>सीएडी फ़ीचर घुमाएँ</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>फिलेट / चैम्फर सेटिंग्स</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>ऑपरेशन मोड</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>फिलेट (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>चैम्फर (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>फिलेट पैरामीटर</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>इकाई</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>त्रिज्या (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>चाप खंडों की संख्या:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>चैम्फर पैरामीटर</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>दूरी 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>दूरी 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>समान दूरियां (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>चयनित फ़ीचर्स पर लागू करें</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>चयनित फ़ीचर्स के सभी शीर्षों पर फिलेट या चैम्फर लागू करें</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>फिलेट</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>चैम्फर</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>त्रिज्या</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>त्रिज्या लॉक / अनलॉक करें</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>फिलेट खंड</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>दूरी 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>दूरी 1 लॉक / अनलॉक करें</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>दूरी 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>दूरी 2 लॉक / अनलॉक करें</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>दूरियां लिंक हैं (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>अलग-अलग दूरियां (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>शीर्ष फिलेट</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>शीर्ष चैम्फर</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>कोना पुनर्स्थापित करें</translation>
        </message>
    </context>
</TS>
