<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="bg">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>3. Задайте радіус/фаску курсором або зафіксуйте кліком</source>
            <translation>3. Задайте радиус/фаска с курсора или щракнете за потвърждение</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Посочете първата линия</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Посочете втората линия</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Закръгляване / Фаска на две линии (Обединяване)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Свързване на две линии със закръгляване или фаска и обединяване на обектите</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Закръгляване / фаска на две линии с обединяване</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Закръгляване / фаска на линия</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Винаги използвай атрибутите на първия обект</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>При обединяване на две линии автоматично запазвай атрибутите на първия обект без показване на диалогов прозорец на QGIS</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Закръгляване / Фаска (Пакетна обработка)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Панел за пакетно закръгляване и фаска за избраните обекти</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Инструмент Закръгляване / Фаска</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Инструмент за създаване на закръгления и фаски върху векторни геометрии</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Закръгляване и фаска</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Внимание</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Активният слой трябва да бъде векторен слой в режим на редактиране.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Информация</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Няма избрани обекти за обработка.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Пакетно закръгляване</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Пакетна фаска</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Успех</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Обработени {} обекта.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Посочете първия ръб на ъгъла</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Посочете съседния втори ръб</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Възстановяване на ъгли (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Интерактивен инструмент за възстановяване на остри ъгли (премахва закръгления и фаски)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>За пакетна обработка слоят трябва да бъде в режим на редактиране и да съдържа избрани обекти</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Параметри на Закръгляване / Фаска</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Режим на операция</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Закръгляване (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Фаска (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Параметри на закръгляването</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>ед.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Радиус (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Брой сегменти на дъгата:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Параметри на фаската</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Разстояние 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Разстояние 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Равни разстояния (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Приложи към избраните обекти</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Приложи закръгляване или фаска към всички върхове на избраните обекти</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Закръгляване</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Фаска</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Радиус</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Заключване / отключване на радиуса</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Сегменти на закръгляването</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Разстояние 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Заключване / отключване на разстояние 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Разстояние 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Заключване / отключване на разстояние 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Свързани разстояния (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Разделни разстояния (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Закръгляване на връх</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Фаска на връх</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Възстановяване на ъгъл</translation>
        </message>
    </context>
</TS>
