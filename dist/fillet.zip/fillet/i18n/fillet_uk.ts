<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="uk">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Пакетна обробка)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Інструмент Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Увага</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Активний шар повинен бути векторним і перебувати в режимі редагування.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Інфо</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Немає виділених об'єктів для обробки.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Пакетне скруглення</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Пакетна фаска</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Успіх</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Оброблено {} об'єкт(ів).</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Відновлення кутів (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Параметри Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Режим операції</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Скруглення (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Фаска (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Параметри скруглення</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>од.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Радіус (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Кількість сегментів дуги:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Параметри фаски</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Відстань 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Відстань 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Однакові відстані (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Застосувати до виділених об'єктів</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Скруглення</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Фаска</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Радіус</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Блокувати / розблокувати радіус</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Сегменти дуги</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Відстань 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Блокувати / розблокувати відстань 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Відстань 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Блокувати / розблокувати відстань 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Відстані зв'язані (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Відстані роздільні (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Скруглення вершини</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Фаска вершини</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Відновлення кута</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>Відновлення гострого кута</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>Крок 1: Клікніть на перше ребро кута</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>ПКМ або Esc — скасувати</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>Скасувати</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>Відновлення кута</translation>
        </message>
    </context>
</TS>
