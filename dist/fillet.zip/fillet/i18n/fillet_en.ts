<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="en">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Specify first line</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Specify second line</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Specify radius or click to confirm</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Specify chamfer or click to confirm</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Two-Line Fillet / Chamfer (Merge)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Join two lines with fillet or chamfer and merge features</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Two-line fillet / chamfer with merge</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Line fillet / chamfer</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Always use attributes of first feature</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>When merging two lines, automatically keep attributes of first feature without showing QGIS dialog</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Batch)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Batch Fillet and Chamfer panel for selected features</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Tool</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Tool for creating fillets and chamfers on vector geometries</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Warning</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Active layer must be a vector layer in editing mode.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Info</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>No selected features to process.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Batch Fillet</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Batch Chamfer</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Success</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Processed {} feature(s).</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Specify first corner edge</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Specify adjacent second edge</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Corner Restoration (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interactive tool to restore sharp corners (removes fillets and chamfers)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>For batch processing, layer must be editable and contain selected features</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Settings</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Operation Mode</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Fillet Parameters</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>u.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Radius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Arc segments count:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Chamfer Parameters</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Distance 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Distance 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Equal distances (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Apply to Selected Features</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Apply fillet or chamfer to all vertices of selected features</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Radius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lock / unlock radius</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Fillet segments</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Distance 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lock / unlock distance 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Distance 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lock / unlock distance 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Distances linked (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Distances unlinked (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Vertex fillet</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Vertex chamfer</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Restore Corner</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Rotate</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interactive CAD geometry rotation tool with center pivot selection</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Specify center pivot</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Specify reference baseline</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Specify rotation angle</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Angle:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Lock angle / interactive rotation</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Snap step:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Free</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Save copy (Copy)</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creates a rotated copy of selected features, preserving the original</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Rotate Feature(s)</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD Mirror</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD Scale &amp; Rotate</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Interactive CAD tool to scale and rotate geometries relative to reference points</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Scale:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Lock scale / free interactive calculation</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Click origin pivot point</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Click reference base point</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Click target scale &amp; angle</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creates a scaled and rotated copy of selected features, leaving the original intact</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD Scale &amp; Rotate Feature(s)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Interactive CAD tool to reflect geometries across a 2-point axis</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Specify first axis point</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Specify second axis point</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Axis snap:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Ortho)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creates a mirrored copy of selected features, keeping the original</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD Mirror Copy</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD Mirror</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Axis angle:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Lock axis angle / interactive pick</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Angle:</translation>
        </message>
    </context>
</TS>
