<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="en">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>3. Задайте радіус/фаску курсором або зафіксуйте кліком</source>
            <translation>3. Set radius/chamfer with cursor or click to commit</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Specify first line</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Specify second line</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Two-Line Fillet / Chamfer (Merge)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Join two lines with fillet or chamfer and merge features</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Two-line fillet / chamfer with merge</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Line fillet / chamfer</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Always use attributes of first feature</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>When merging two lines, automatically keep attributes of first feature without showing QGIS dialog</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Batch)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Batch Fillet and Chamfer panel for selected features</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Tool</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Tool for creating fillets and chamfers on vector geometries</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Warning</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Active layer must be a vector layer in editing mode.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Info</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>No selected features to process.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Batch Fillet</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Batch Chamfer</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Success</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Processed {} feature(s).</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Specify first corner edge</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Specify adjacent second edge</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Corner Restoration (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interactive tool to restore sharp corners (removes fillets and chamfers)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>For batch processing, layer must be editable and contain selected features</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Fillet / Chamfer Settings</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Operation Mode</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Fillet Parameters</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>u.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Radius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Arc segments count:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Chamfer Parameters</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Distance 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Distance 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Equal distances (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Apply to Selected Features</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Apply fillet or chamfer to all vertices of selected features</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Radius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lock / unlock radius</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Fillet segments</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Distance 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lock / unlock distance 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Distance 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lock / unlock distance 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Distances linked (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Distances unlinked (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Vertex fillet</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Vertex chamfer</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Restore Corner</translation>
        </message>
    </context>
</TS>
