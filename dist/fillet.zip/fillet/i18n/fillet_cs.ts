<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="cs">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Полярний масив (Polar Array)</source>
            <translation>CAD Polární pole (Polar Array)</translation>
        </message>
        <message>
            <source>Створення кругового (полярного) масиву копій виділених об'єктів навколо центру</source>
            <translation>Vytvoření kruhového (polárního) pole kopií vybraných prvků kolem středu</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання / об'єкт</source>
            <translation>1. Určete střed otáčení / prvek</translation>
        </message>
        <message>
            <source>2. Вкажіть кут / радіус масиву</source>
            <translation>2. Určete úhel / poloměr pole</translation>
        </message>
        <message>
            <source>Фіксована кількість елементів у полярному масиві</source>
            <translation>Pevný počet položek v polárním poli</translation>
        </message>
        <message>
            <source>Крок (Step angle):</source>
            <translation>Krokový úhel (Step angle):</translation>
        </message>
        <message>
            <source>Фіксований кутовий крок між елементами масиву</source>
            <translation>Pevný úhlový krok mezi prvky pole</translation>
        </message>
        <message>
            <source>Кут (Fill angle):</source>
            <translation>Úhel vyplnění (Fill angle):</translation>
        </message>
        <message>
            <source>Загальний кут заповнення полярного масиву (360° = повне коло)</source>
            <translation>Celkový úhel vyplnění polárního pole (360° = plný kruh)</translation>
        </message>
        <message>
            <source>Обертати об'єкти (Rotate):</source>
            <translation>Otočit prvky (Rotate):</translation>
        </message>
        <message>
            <source>Якщо увімкнено, кожна копія повертається за рухом кола; якщо вимкнено — зберігає вихідний азимут</source>
            <translation>Je-li povoleno, každá kopie se otáčí podél kružnice; je-li zakázáno, zůstane zachován původní azimut</translation>
        </message>
        <message>
            <source>CAD Polar Array Feature(s)</source>
            <translation>CAD Polární pole prvků</translation>
        </message>
        <message>
            <source>CAD Розбиття лінії (Explode)</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент розбиття ліній на окремі сегменти або складові частини (multipart)</source>
            <translation>Interactive CAD tool to split lines into individual segments or multipart components</translation>
        </message>
        <message>
            <source>CAD З'єднання ліній (Join)</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент топологічного з'єднання суміжних ліній у неперервні полілінії</source>
            <translation>Interactive CAD tool to topologically chain and join adjacent lines into continuous polylines</translation>
        </message>
        <message>
            <source>1. Оберіть лінію для розбиття на відрізки</source>
            <translation>1. Select a line to explode into segments</translation>
        </message>
        <message>
            <source>Зберегти як складену геометрію (multipart)</source>
            <translation>Save as multipart geometry</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single object (MultiLineString)</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного складеного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single multipart object (MultiLineString)</translation>
        </message>
        <message>
            <source>Шар є SinglePart (LineString) і не підтримує multipart</source>
            <translation>Layer is SinglePart (LineString) and does not support multipart</translation>
        </message>
        <message>
            <source>Розбити виділені лінії</source>
            <translation>Explode selected lines</translation>
        </message>
        <message>
            <source>Розбити виділені лінії ({})</source>
            <translation>Explode selected lines ({})</translation>
        </message>
        <message>
            <source>Розбиття ліній на складові частини (multipart)</source>
            <translation>Explode lines to multipart components</translation>
        </message>
        <message>
            <source>Розбиття ліній на окремі відрізки</source>
            <translation>Explode lines into separate segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків</source>
            <translation>Successfully exploded {} feature(s) into {} segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків (пропущено {} одинарних відрізків)</source>
            <translation>Successfully exploded {} feature(s) into {} segments (skipped {} single segment(s))</translation>
        </message>
        <message>
            <source>Об'єкт вже є простим відрізком (2 точки) і не може бути розділений</source>
            <translation>Feature is already a single segment (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>Усі виділені об'єкти вже є простими відрізками (2 точки) і не можуть бути розділені</source>
            <translation>All selected features are already single segments (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>CAD Explode Line</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>1. Оберіть першу лінію для з'єднання</source>
            <translation>1. Select first line to join</translation>
        </message>
        <message>
            <source>2. Оберіть суміжні лінії (Enter для фіксації)</source>
            <translation>2. Select adjacent lines (Enter to commit)</translation>
        </message>
        <message>
            <source>Допуск вузлів:</source>
            <translation>Node tolerance:</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії ({})</source>
            <translation>Join selected lines ({})</translation>
        </message>
        <message>
            <source>З'єднання ліній у полілінію</source>
            <translation>Join lines into polyline</translation>
        </message>
        <message>
            <source>З'єднання виділених ліній</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>CAD Join Lines</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} ліній в єдину полілінію</source>
            <translation>Successfully joined {} lines into a single polyline</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} виділених ліній в {} поліліній</source>
            <translation>Successfully joined {} selected lines into {} polylines</translation>
        </message>
        <message>
            <source>Кількість (Count):</source>
            <translation>Počet prvků:</translation>
        </message>
        <message>
            <source>Крок (Spacing):</source>
            <translation>Rozestup:</translation>
        </message>
        <message>
            <source>Фіксована кількість нових копій об'єктів у масиві</source>
            <translation>Pevný počet nových kopií prvků v poli</translation>
        </message>
        <message>
            <source>Фіксована відстань (крок) між копіями об'єктів у масиві</source>
            <translation>Pevná vzdálenost (rozestup) mezi kopiemi prvků v poli</translation>
        </message>
        <message>
            <source>1. Вкажіть початкову точку / об'єкт</source>
            <translation>1. Klikněte na počáteční bod / prvek</translation>
        </message>
        <message>
            <source>2. Вкажіть кінцеву точку / крок</source>
            <translation>2. Klikněte na koncový bod / rozestup</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів (Copy in Array)</source>
            <translation>CAD Pole prvků (Copy in Array)</translation>
        </message>
        <message>
            <source>Створення масиву копій виділених об'єктів уздовж напрямної лінії</source>
            <translation>Kopírovat prvky v poli podél referenční linie</translation>
        </message>
        <message>
            <source>Параметри масиву (Feature Array)</source>
            <translation>Konfigurace pole prvků</translation>
        </message>
        <message>
            <source>Режим:</source>
            <translation>Režim:</translation>
        </message>
        <message>
            <source>Крок між об'єктами (од. карти):</source>
            <translation>Rozestup mezi prvky (mapové jednotky):</translation>
        </message>
        <message>
            <source>Кількість нових копій:</source>
            <translation>Počet nových prvků:</translation>
        </message>
        <message>
            <source>Кількість об'єктів (Feature Count)</source>
            <translation>Počet prvků</translation>
        </message>
        <message>
            <source>Крок / Відстань (Spacing)</source>
            <translation>Rozestup</translation>
        </message>
        <message>
            <source>Крок і кількість (Spacing &amp; Count)</source>
            <translation>Rozestup a počet prvků</translation>
        </message>
        <message>
            <source>CAD масив об'єктів</source>
            <translation>CAD pole prvků</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів</source>
            <translation>CAD Pole prvků</translation>
        </message>
        <message>
            <source>Очищення топології</source>
            <translation>Čištění topologie</translation>
        </message>
        <message>
            <source>Об'єкт успішно очищено та розділено на {0} окремих об'єктів.</source>
            <translation>Objekt byl úspěšně vyčištěn a rozdělen na {0} samostatných objektů.</translation>
        </message>
        <message>
            <source>Успішно виправлено геометрію об'єкта (усунуто {0} помилок).</source>
            <translation>Geometrie objektu byla úspěšně opravena ({0} chyb vyřešeno).</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити {1})</source>
            <translation>Ponechat uzel #{0} (odstranit {1})</translation>
        </message>
        <message>
            <source>Злити всі {0} дублів у вершині (залишити 1 вузол)</source>
            <translation>Sloučit všechny {0} duplikáty ve vrcholu (ponechat 1 uzel)</translation>
        </message>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Vyčistit duplicitní uzly</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Rychlé vyčištění a oprava duplicitních uzlů geometrie</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Sloučit duplicity ve vrcholu (ponechat 1 uzel)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Ponechat uzel #{0} (odstranit #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Vyčistit všechny duplicity a chyby v prvku ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Vyčištění duplicitních uzlů</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Rozplést samoprotínající se smyčku</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Rozpletení samoprotnutí</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Rozdělit na vícenásobnou geometrii (MultiPart)</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Rozplést / ponechat hlavní tělo</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Rozdělit na {0} samostatných prvků</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Rozdělení na samostatné prvky</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Automaticky opravit geometrii (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Oprava geometrie</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Vyčištění topologických chyb</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Typ geometrie vrstvy</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>Aktuální vrstva nepodporuje vícenásobné geometrie (MultiPart).

Výsledek opravy obsahuje více částí ({0}). Vyberte způsob uložení:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Rozdělit na samostatné SinglePart prvky</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Ponechat jako MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Vyčištění geometrie (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Rychlé vyčištění duplicitních uzlů a chyb</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Vyčistit a rozdělit na samostatné prvky</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Určete první linii</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Určete druhou linii</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Určete poloměr nebo klikněte pro potvrzení</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Určete zkosení nebo klikněte pro potvrzení</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Zaoblení / Zkosení dvou linií (Sloučit)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Spojit dvě linie zaoblením nebo zkosením a sloučit prvky</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Zaoblení / zkosení dvou linií se sloučením</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Zaoblení / zkosení linie</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Vždy použít atributy prvního prvku</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>Při slučování dvou linií automaticky zachovat atributy prvního prvku bez zobrazení dialogu QGIS</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Zaoblení / Zkosení (Dávkově)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panel dávkového zaoblení a zkosení pro vybrané prvky</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Nástroj Zaoblení / Zkosení</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Nástroj pro tvorbu zaoblení a zkosení na vektorových geometriích</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Zaoblení a zkosení</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Varování</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktivní vrstva musí být vektorová vrstva v režimu úprav.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informace</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Žádné vybrané prvky ke zpracování.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Dávkové zaoblení</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Dávkové zkosení</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Úspěch</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Zpracováno {} prvků.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Určete první hranu rohu</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Určete sousední druhou hranu</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Obnova rohů (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interaktivní nástroj pro obnovu ostrých rohů (odstraní zaoblení a zkosení)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Pro dávkové zpracování musí být vrstva upravitelná a obsahovat vybrané prvky</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Nastavení Zaoblení / Zkosení</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Režim operace</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Zaoblení (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Zkosení (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Parametry zaoblení</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>j.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Poloměr (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Počet segmentů oblouku:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Parametry zkosení</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Vzdálenost 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Vzdálenost 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Stejné vzdálenosti (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Použít na vybrané prvky</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Použít zaoblení nebo zkosení na všechny lomové body vybraných prvků</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Zaoblení</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Zkosení</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Poloměr</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Zamknout / odemknout poloměr</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segmenty zaoblení</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Vzdálenost 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Zamknout / odemknout vzdálenost 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Vzdálenost 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Zamknout / odemknout vzdálenost 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Vzdálenosti propojeny (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Vzdálenosti oddělené (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Zaoblení vrcholu</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Zkosení vrcholu</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Obnovit roh</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Otočit</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktivní CAD nástroj pro otáčení geometrií s výběrem středu otáčení</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Zadejte střed otáčení</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Zadejte referenční směr</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Zadejte úhel otáčení</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Úhel:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Zamknout úhel / interaktivní otáčení</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Krok přichytávání:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Volný</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Uložit kopii</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Vytvoří otočenou kopii vybraných prvků a zachová originál</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Otočení prvků</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD Zrcadlení</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD Měřítko a Otočení</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Interaktivní CAD nástroj pro změnu měřítka a otočení geometrií vzhledem k referenčním bodům</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Měřítko:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Zamknout měřítko / volný výpočet</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Klikněte na počáteční bod</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Klikněte na referenční bod</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Klikněte na cílové měřítko a úhel</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Vytvoří změněnou a otočenou kopii vybraných prvků a ponechá originál</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD změna měřítka a otočení prvků</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Interaktivní CAD nástroj pro zrcadlení geometrií podle 2bodové osy</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Určete první bod osy</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Určete druhý bod osy</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Přichytávání osy:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Orto)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Vytvoří zrcadlenou kopii vybraných prvků a zachová originál</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD Zrcadlová kopie</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD Zrcadlení</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Úhel osy:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Zamknout úhel osy / interaktivní výběr</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Úhel:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Určete hranu (vyberte segment)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Určete odsazení nebo klikněte pro potvrzení</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD Odsazení hrany (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Interaktivní CAD nástroj pro paralelní odsazení segmentu hrany polygonu nebo křivky</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Zamknout vzdálenost / interaktivní výpočet</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Vzdálenost:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Odsazení hrany</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Prodloužit (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Vytvoří nový prvek s odsazenou hranou místo úpravy původního</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Schod (Step)</translation>
        </message>
    </context>
</TS>
