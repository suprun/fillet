<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="da">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Afrunding / Affasning (Batchbehandling)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panel til batchafrunding og -affasning af valgte elementer</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Afrundings- / affasningsværktøj</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Værktøj til oprettelse af afrundinger og affasninger på vektorgeometrier</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Afrunding &amp; Affasning</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Advarsel</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Det aktive lag skal være et vektorlag i redigeringstilstand.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Information</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Ingen valgte objekter at behandle.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Batchafrunding</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Batchaffasning</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Succes</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Behandlede {} objekter.</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Roter</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktivt CAD-værktøj til rotation af geometrier med valg af drejepunkt</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Indstillinger for afrunding / affasning</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Handlingstilstand</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Afrunding (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Affasning (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Afrundingsparametre</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>enh.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Radius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Antal buesegmenter:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Affasningsparametre</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Afstand 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Afstand 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Ens afstande (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Anvend på valgte objekter</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Anvend afrunding eller affasning på alle knudepunkter i de valgte objekter</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Afrunding</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Affasning</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Radius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lås / lås radius op</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Afrundingssegmenter</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Afstand 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lås / lås afstand 1 op</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Afstand 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lås / lås afstand 2 op</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Koblede afstande (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Uafhængige afstande (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Knudepunktsafrunding</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Knudepunktsaffasning</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Gendan hjørne</translation>
        </message>
    </context>
    <context>
        <name>RotationCanvasWidget</name>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Angiv drejepunkt</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Angiv referenceretning</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Angiv rotationsvinkel</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Vinkel:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Lås vinkel / interaktiv rotation</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Snappe-trin:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Fri</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Gem kopi</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Opretter en roteret kopi af valgte objekter og bevarer originalen</translation>
        </message>
    </context>
    <context>
        <name>RotateMapTool</name>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Roter objekt(er)</translation>
        </message>
    </context>
</TS>
