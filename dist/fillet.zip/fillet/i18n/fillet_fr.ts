<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="fr">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Traitement par lot)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panneau de traitement par lot pour congés (fillet) et chanfreins des entités sélectionnées</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Outil Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Outil pour créer des arrondis (congés) et des chanfreins sur les géométries vectorielles</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Avertissement</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>La couche active doit être une couche vectorielle en mode édition.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Info</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Aucune entité sélectionnée à traiter.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Congé par lot</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Chanfrein par lot</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Succès</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>{} entité(s) traitée(s).</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Spécifier la première arête de l'angle</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Spécifier la deuxième arête adjacente</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Restauration d'angles (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Outil interactif pour restaurer les angles vifs (supprime les congés et chanfreins)</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Spécifier le centre de rotation (Pivot)</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Spécifier la ligne de référence</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Spécifier l'angle de rotation cible</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>Rotation CAD</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Outil interactif de rotation CAD pour géométries avec sélection du point de pivot</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Angle :</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Verrouiller l'angle / rotation interactive</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Pas d'accrochage :</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Libre</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Conserver la copie</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Crée une copie pivotée des entités sélectionnées en conservant l'original</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Pour le traitement par lots, la couche doit être modifiable et contenir des entités sélectionnées</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>Rotation CAD d'entité(s)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Paramètres Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Mode d'opération</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Congé (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Chanfrein (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Paramètres de congé</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>u.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Rayon (R) :</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Nombre de segments d'arc :</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Paramètres de chanfrein</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Distance 1 (d1) :</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Distance 2 (d2) :</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Distances égales (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Appliquer aux entités sélectionnées</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Appliquer un congé ou un chanfrein à tous les sommets des entités sélectionnées</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Rayon</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Verrouiller / déverrouiller le rayon</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segments de congé</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Distance 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Verrouiller / déverrouiller la distance 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Distance 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Verrouiller / déverrouiller la distance 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Distances liées (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Distances séparées (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Congé de sommet</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Chanfrein de sommet</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Restaurer l'angle</translation>
        </message>
    </context>
</TS>
