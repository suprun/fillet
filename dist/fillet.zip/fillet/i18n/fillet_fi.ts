<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="fi">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Puhdista kaksoissolmut</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Geometrian kaksoissolmujen nopea puhdistus ja korjaus</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Yhdistä kärjen kaksoissolmut (säilytä 1 solmu)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Säilytä solmu #{0} (poista #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Puhdista kaikki kohteen kaksoissolmut ja virheet ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Kaksoissolmujen puhdistus</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Selvitä itseään leikkaava silmukka</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Itseään leikkaavan silmukan selvitys</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Jaa moniosaiseen geometriaan</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Selvitä / säilytä päärunko</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Jaa {0} erilliseen kohteeseen</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Jako erillisiin kohteisiin</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Korjaa geometria automaattisesti (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Korjaa geometria</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Topologiavirheiden puhdistus</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Tason geometriatyyppi</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>Nykyinen taso ei tue moniosaisia geometrioita (MultiPart).

Korjaustulos sisältää useita osia ({0}). Valitse tallennustapa:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Jaa erillisiin SinglePart-kohteisiin</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Säilytä MultiPart-muodossa</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Geometrian puhdistus (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Kaksoissolmujen ja virheiden nopea puhdistus</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Puhdista ja jaa erillisiin kohteisiin</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Määritä ensimmäinen viiva</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Määritä toinen viiva</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Määritä säde tai vahvista napsauttamalla</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Määritä viiste tai vahvista napsauttamalla</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Kahden viivan pyöristys / viiste (Yhdistä)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Yhdistä kaksi viivaa pyöristyksellä tai viisteellä ja sulauta kohteet</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Kahden viivan pyöristys / viiste yhdistämisellä</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Viivan pyöristys / viiste</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Käytä aina ensimmäisen kohteen attribuutteja</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>Kun yhdistät kaksi viivaa, säilytä ensimmäisen kohteen attribuutit automaattisesti näyttämättä QGIS-valintaikkunaa</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Pyöristys / Viiste (Eräajo)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Eräajopyöristys- ja viistepaneeli valituille kohteille</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Pyöristys / Viiste -työkalu</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Työkalu pyöristysten ja viisteiden luomiseen vektorigeometrioille</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Pyöristys &amp; Viiste</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Varoitus</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktiivisen tason on oltava vektoritaso muokkaustilassa.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Tiedot</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Ei valittuja kohteita käsiteltäväksi.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Eräpyöristys</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Eräviiste</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Valmis</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Käsitelty {} kohdetta.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Määritä ensimmäinen kulmasärmä</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Määritä viereinen toinen särmä</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Kulmien palautus (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interaktiivinen työkalu terävien kulmien palauttamiseen (poistaa pyöristykset ja viisteet)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Eräkäsittelyä varten tason on oltava muokattavissa ja sisällettävä valittuja kohteita</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Pyöristys / Viiste -asetukset</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Toimintatila</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Pyöristys (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Viiste (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Pyöristyksen parametrit</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>yks.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Säde (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Kaaren segmenttien määrä:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Viisteen parametrit</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Etäisyys 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Etäisyys 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Yhtä suuret etäisyydet (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Käytä valittuihin kohteisiin</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Käytä pyöristystä tai viistettä valittujen kohteiden kaikkiin taitteisiin</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Pyöristys</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Viiste</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Säde</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lukitse / avaa säde</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Pyöristyksen segmentit</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Etäisyys 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lukitse / avaa etäisyys 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Etäisyys 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lukitse / avaa etäisyys 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Etäisyydet linkitetty (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Erilliset etäisyydet (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Taitteen pyöristys</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Taitteen viiste</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Palauta kulma</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Kierrä</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktiivinen CAD-geometrioiden pyöritystyökalu kääntöpisteen valinnalla</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Määritä kääntöpiste</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Määritä viitesuunta</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Määritä pyörityskulma</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Kulma:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Lukitse kulma / interaktiivinen pyöritys</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Tartunnan askel:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Vapaa</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Tallenna kopio</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Luo valituista kohteista kierretyn kopion säilyttäen alkuperäisen</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Kohteiden pyöritys</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD Peilaus</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD Mittakaava ja Kierto</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Interaktiivinen CAD-työkalu geometrioiden mittakaavan muuttamiseen ja kiertämiseen suhteessa viitepisteisiin</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Mittakaava:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Lukitse mittakaava / vapaa laskenta</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Napsauta aloituspistettä</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Napsauta viitepistettä</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Napsauta tavoitemittakaavaa ja -kulmaa</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Luo valituista kohteista skaalatun ja kierretyn kopion jättäen alkuperäisen ennalleen</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD Mittakaavan muutos ja kierto kohteille</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Interaktiivinen CAD-työkalu geometrioiden peilaamiseen 2-pisteakselin suhteen</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Määritä akselin ensimmäinen piste</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Määritä akselin toinen piste</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Akselisidonta:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Orto)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Luo peilatun kopion valituista kohteista säilyttäen alkuperäisen</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD Peilauskopio</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD Peilaus</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Akselikulma:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Lukitse akselikulma / interaktiivinen valinta</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Kulma:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Määritä reuna (valitse segmentti)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Määritä siirtymä tai vahvista napsauttamalla</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD Reunan siirtymä (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Interaktiivinen CAD-työkalu monikulmion tai murtoviivan reunan rinnakkaissiirtoon</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Lukitse etäisyys / interaktiivinen laskenta</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Etäisyys:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Reunan siirtymä</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Jatka (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Luo uusi kohde siirretyllä reunalla alkuperäisen muokkaamisen sijaan</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Porras (Step)</translation>
        </message>
    </context>
</TS>
