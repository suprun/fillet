<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="fi">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Pyöristys / Viiste (Eräajo)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Eräajopyöristys- ja viistepaneeli valituille kohteille</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Pyöristys / Viiste -työkalu</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Työkalu pyöristysten ja viisteiden luomiseen vektorigeometrioille</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Pyöristys &amp; Viiste</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Varoitus</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktiivisen tason on oltava vektoritaso muokkaustilassa.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Tiedot</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Ei valittuja kohteita käsiteltäväksi.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Eräpyöristys</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Eräviiste</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Valmis</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Käsitelty {} kohdetta.</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Palauta kulmat (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Terävien kulmien palautustyökalu (poistaa pyöristykset ja viisteet)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Pyöristys / Viiste -asetukset</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Toimintatila</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Pyöristys (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Viiste (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Pyöristyksen parametrit</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>yks.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Säde (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Kaaren segmenttien määrä:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Viisteen parametrit</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Etäisyys 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Etäisyys 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Yhtä suuret etäisyydet (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Käytä valittuihin kohteisiin</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Käytä pyöristystä tai viistettä valittujen kohteiden kaikkiin taitteisiin</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Pyöristys</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Viiste</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Säde</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lukitse / avaa säde</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Pyöristyksen segmentit</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Etäisyys 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lukitse / avaa etäisyys 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Etäisyys 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lukitse / avaa etäisyys 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Etäisyydet linkitetty (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Erilliset etäisyydet (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Taitteen pyöristys</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Taitteen viiste</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Palauta kulma</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>Palauta terävä kulma</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>Vaihe 1: Napsauta kulman ensimmäistä reunaa</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>Vaihe 2: Napsauta viereistä toista reunaa kulman rekonstruoimiseksi</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>Oikea painike tai Esc — Peruuta</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>Peruuta</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>Palauta kulma</translation>
        </message>
    </context>
</TS>
