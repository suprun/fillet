<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="et">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Залишити вузол #{0} (видалити {1})</source>
            <translation>Säilita sõlm #{0} (eemalda {1})</translation>
        </message>
        <message>
            <source>Злити всі {0} дублів у вершині (залишити 1 вузол)</source>
            <translation>Ühenda kõik {0} duplikaati tipus (säilita 1 sõlm)</translation>
        </message>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Puhasta duplikaatsõlmed</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Geomeetria duplikaatsõlmede kiirpuhastus ja parandus</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Ühenda tipu duplikaadid (säilita 1 sõlm)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Säilita sõlm #{0} (eemalda #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Puhasta kõik objekti duplikaadid ja vead ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Duplikaatsõlmede puhastamine</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Haruta lahti eneselõikuse silmus</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Eneselõikuse harutamine</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Jaga mitmeosaliseks geomeetriaks</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Haruta lahti / säilita põhiosa</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Jaga {0} eraldi objektiks</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Jagamine eraldi objektideks</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Paranda geomeetria automaatselt (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Geomeetria parandamine</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Topoloogiavigade puhastamine</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Kihi geomeetria tüüp</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>Praegune kiht ei toeta mitmeosalisi geomeetriaid (MultiPart).

Paranduse tulemus sisaldab mitut osa ({0}). Valige salvestamise viis:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Jaga eraldi SinglePart objektideks</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Säilita kui MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Geomeetria puhastamine (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Duplikaatsõlmede ja vigade kiirpuhastus</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Puhasta ja jaga eraldi objektideks</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Määrake esimene joon</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Määrake teine joon</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Määrake raadius või klõpsake kinnitamiseks</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Määrake faas või klõpsake kinnitamiseks</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Kahe joone ümardamine / faasimine (Ühenda)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Ühendage kaks joont ümardamise või faasimisega ja liitke objektid</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Kahe joone ümardamine / faasimine ühendamisega</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Joone ümardamine / faasimine</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Kasuta alati esimese objekti atribuute</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>Kahe joone ühendamisel säilita automaatselt esimese objekti atribuudid ilma QGIS dialoogi kuvamata</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Ümardamine / Faasimine (Pakktöötlus)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Valitud objektide partiiümardamise ja faasimise paneel</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Ümardamise / faasimise tööriist</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Tööriist vektorite ümardamiseks ja faasimiseks</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Ümardamine ja faasimine</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Hoiatus</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktiivne kiht peab olema muutmise režiimis vektorikiht.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Teave</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Töötlemiseks pole valitud objekte.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Pakkümardamine</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Pakkfaasimine</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Õnnestus</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Töödeldud {} objekti.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Määrake esimene nurgaserv</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Määrake külgnev teine serv</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Nurkade taastamine (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interaktiivne tööriist teravate nurkade taastamiseks (eemaldab ümardused ja faasid)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Pakktöötluseks peab kiht olema muudetav ja sisaldama valitud objekte</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Ümardamise / faasimise seaded</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Toimingu režiim</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Ümardamine (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Faasimine (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Ümardamise parameetrid</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>üh.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Raadius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Kaare segmentide arv:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Faasimise parameetrid</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Kaugus 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Kaugus 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Võrdsed kaugused (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Rakenda valitud objektidele</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Rakenda ümardamist või faasimist kõigile valitud objektide tippudele</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Ümarda</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Faasi</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Raadius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lukusta / vabasta raadius</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Ümardamise segmendid</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Kaugus 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lukusta / vabasta kaugus 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Kaugus 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lukusta / vabasta kaugus 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Kaugused seotud (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Kaugused eraldi (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Tippude ümardamine</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Tippude faasimine</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Taasta nurk</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Pööra</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktiivne CAD-geomeetria pööramise tööriist pöördepunkti valikuga</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Määra pöördepunkt</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Määra võrdlussuund</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Määra pöördenurk</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Nurk:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Lukusta nurk / interaktiivne pööramine</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Haardumissamm:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Vaba</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Salvesta koopia</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Loob valitud objektidest pööratud koopia, säilitades originaali</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Objektide pööramine</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD Peegeldus</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD Mõõtkava ja Pööramine</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Interaktiivne CAD-tööriist geomeetriate skaleerimiseks ja pööramiseks võrdluspunktide suhtes</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Mõõtkava:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Lukusta mõõtkava / vaba arvutus</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Klõpsake alguspunkti</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Klõpsake võrdluspunkti</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Klõpsake sihtmõõtkaval ja -nurgal</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Loob valitud objektidest skaleeritud ja pööratud koopia, jättes originaali puutumata</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD Objektide skaleerimine ja pööramine</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Interaktiivne CAD-tööriist geomeetriate peegeldamiseks piki 2-punktilist telge</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Määrake telje esimene punkt</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Määrake telje teine punkt</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Telje haaramine:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Rist)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Loob valitud objektidest peegeldatud koopia, säilitades originaali</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD Peegelkopeerimine</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD Peegeldus</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Telje nurk:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Lukusta telje nurk / interaktiivne valik</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Nurk:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Määrake serv (valige segment)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Määrake nihe või klõpsake kinnitamiseks</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD Serva nihe (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Interaktiivne CAD-tööriist polügooni või polüjoone serva paralleelseks nihutamiseks</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Lukusta vahemaa / interaktiivne arvutus</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Vahemaa:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Serva nihe</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Pikenda (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Loob uue objekti nihutatud servaga originaali muutmise asemel</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Aste (Step)</translation>
        </message>
    </context>
</TS>
