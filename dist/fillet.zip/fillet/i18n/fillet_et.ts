<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="et">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Ümardamine / Faasimine (Pakktöötlus)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Valitud objektide partiiümardamise ja faasimise paneel</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Ümardamise / faasimise tööriist</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Tööriist vektorite ümardamiseks ja faasimiseks</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Ümardamine ja faasimine</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Hoiatus</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktiivne kiht peab olema muutmise režiimis vektorikiht.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Teave</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Töötlemiseks pole valitud objekte.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Pakkümardamine</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Pakkfaasimine</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Õnnestus</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Töödeldud {} objekti.</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Taasta nurgad (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Teravate nurkade taastamise tööriist (eemaldab ümardused ja faasid)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Ümardamise / faasimise seaded</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Toimingu režiim</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Ümardamine (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Faasimine (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Ümardamise parameetrid</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>üh.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Raadius (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Kaare segmentide arv:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Faasimise parameetrid</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Kaugus 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Kaugus 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Võrdsed kaugused (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Rakenda valitud objektidele</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Rakenda ümardamist või faasimist kõigile valitud objektide tippudele</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Ümarda</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Faasi</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Raadius</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Lukusta / vabasta raadius</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Ümardamise segmendid</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Kaugus 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Lukusta / vabasta kaugus 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Kaugus 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Lukusta / vabasta kaugus 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Kaugused seotud (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Kaugused eraldi (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Tippude ümardamine</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Tippude faasimine</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Taasta nurk</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>Taasta terav nurk</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>1. samm: klõpsake nurga esimesel serval</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>2. samm: klõpsake külgneval teisel serval nurga taastamiseks</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>Paremklõps või Esc — Tühista</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>Tühista</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>Taasta nurk</translation>
        </message>
    </context>
</TS>
