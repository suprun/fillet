<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="id">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Fillet / Chamfer (Tumpak)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panel fillet dan chamfer batch untuk fitur terpilih</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Alat Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Alat untuk membuat fillet dan chamfer pada geometri vektor</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Fillet &amp; Chamfer</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Peringatan</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Lapisan aktif harus berupa lapisan vektor dalam mode pengeditan.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Info</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Tidak ada fitur terpilih untuk diproses.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Fillet Tumpak</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Chamfer Tumpak</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Berhasil</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Diproses {} fitur.</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Pulihkan Sudut (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Alat pemulihan sudut tajam (menghapus fillet dan chamfer)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Pengaturan Fillet / Chamfer</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Mode Operasi</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Parameter Fillet</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>sat.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Jari-jari (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Jumlah segmen busur:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Parameter Chamfer</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Jarak 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Jarak 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Jarak sama (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Terapkan ke Fitur Terpilih</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Terapkan fillet atau chamfer ke semua simpul dari fitur yang dipilih</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Fillet</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Chamfer</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Jari-jari</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Kunci / buka kunci jari-jari</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segmen fillet</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Jarak 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Kunci / buka kunci jarak 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Jarak 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Kunci / buka kunci jarak 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Jarak tertaut (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Jarak terpisah (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Fillet simpul</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Chamfer simpul</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Pulihkan Sudut</translation>
        </message>
    </context>
    <context>
        <name>RestoreCanvasWidget</name>
        <message>
            <source>Відновлення гострого кута</source>
            <translation>Pulihkan Sudut Tajam</translation>
        </message>
        <message>
            <source>Крок 1: Клікніть на перше ребро кута</source>
            <translation>Langkah 1: Klik tepi pertama sudut</translation>
        </message>
        <message>
            <source>Крок 2: Клікніть на суміжне друге ребро для зведення в кут</source>
            <translation>Langkah 2: Klik tepi kedua yang berdekatan untuk merekonstruksi sudut</translation>
        </message>
        <message>
            <source>ПКМ або Esc — скасувати</source>
            <translation>Klik kanan atau Esc — Batal</translation>
        </message>
        <message>
            <source>Скасувати</source>
            <translation>Batal</translation>
        </message>
    </context>
    <context>
        <name>RestoreMapTool</name>
        <message>
            <source>Відновлення кута</source>
            <translation>Pulihkan Sudut</translation>
        </message>
    </context>
</TS>
