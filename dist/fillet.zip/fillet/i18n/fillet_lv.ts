<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="lv">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Noapaļošana / Nolīdzināšana (Partija)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Partijas noapaļošanas un nolīdzināšanas panelis atlasītajiem objektiem</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Noapaļošanas / nolīdzināšanas rīks</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Rīks noapaļojumu un nolīdzinājumu veidošanai vektoru ģeometrijās</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Noapaļošana un nolīdzināšana</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Brīdinājums</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktīvajam slānim jābūt vektoru slānim rediģēšanas režīmā.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informācija</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Nav atlasītu objektu apstrādei.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Partijas noapaļošana</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Partijas nolīdzināšana</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Pabeigts</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Apstrādāti {} objekti.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Norādiet pirmo stūra malu</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Norādiet blakus esošo otro malu</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Stūru atjaunošana (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interaktīvs rīks asu stūru atjaunošanai (noņem noapaļojumus un nolīdzinājumus)</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Norādiet rotācijas centru</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Norādiet atsauces bāzes līniju</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Norādiet mērķa rotācijas leņķi</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Rotācija</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktīvs CAD rotācijas rīks ģeometrijām ar rotācijas centra izvēli</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Leņķis:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Bloķēt leņķi / interaktīvā rotācija</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Leņķa solis:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Brīvs</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Saglabāt kopiju</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Izveido atlasīto objektu pagrieztu kopiju, saglabājot oriģinālu</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Pakešapstrādei slānim jābūt rediģējamam un jāsatur atlasītie objekti</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Pagriezt objektu(s)</translation>
        </message>
    </context>
    <context>
        <name>FilletSettingsWidget</name>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Noapaļošanas / nolīdzināšanas iestatījumi</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Darbības režīms</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Noapaļošana (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Nolīdzināšana (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Noapaļošanas parametri</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>vien.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Rādiuss (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Loka segmentu skaits:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Nolīdzināšanas parametri</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Attālums 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Attālums 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Vienādi attālumi (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Lietot atlasītajiem objektiem</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Lietot noapaļošanu vai nolīdzināšanu visām atlasīto objektu virsotnēm</translation>
        </message>
    </context>
    <context>
        <name>FilletCanvasWidget</name>
        <message>
            <source>Fillet</source>
            <translation>Noapaļot</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Nolīdzināt</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Rādiuss</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Bloķēt / atbloķēt rādiusu</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Noapaļošanas segmenti</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Attālums 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Bloķēt / atbloķēt attālumu 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Attālums 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Bloķēt / atbloķēt attālumu 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Attālumi saistīti (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Attālumi atsevišķi (d1 ≠ d2)</translation>
        </message>
    </context>
    <context>
        <name>FilletMapTool</name>
        <message>
            <source>Скруглення вершини</source>
            <translation>Virsotnes noapaļošana</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Virsotnes nolīdzināšana</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Atjaunot stūri</translation>
        </message>
    </context>
</TS>
