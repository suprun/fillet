<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="ca">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Neteja de nodes duplicats</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Neteja i reparació ràpida de nodes de geometria duplicats</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Fusiona duplicats al vèrtex (mantén 1 node)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Mantén el node #{0} (elimina #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Neteja tots els duplicats i errors de l'entitat ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Neteja de nodes duplicats</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Desfés el llaç d'autointersecció</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Desfeta d'autointersecció</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Divideix en geometria multipart</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Desfés / mantén el cos principal</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Divideix en {0} entitats separades</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Divisió en entitats separades</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Repara automàticament la geometria (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Reparació de geometria</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Neteja d'errors topològics</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Tipus de geometria de la capa</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>La capa actual no admet geometries multipart (MultiPart).

El resultat de la reparació conté diverses parts ({0}). Trieu com desar el resultat:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Divideix en entitats SinglePart separades</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Mantén com a MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Neteja de geometria (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Neteja ràpida de nodes duplicats i errors</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Neteja i divideix en entitats separades</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Especifiqueu la primera línia</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Especifiqueu la segona línia</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Especifiqueu el radi o feu clic per confirmar</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Especifiqueu el xamfrà o feu clic per confirmar</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Arrodoniment / Xamfrà de dues línies (Fusiona)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Uneix dues línies amb arrodoniment o xamfrà i fusiona les entitats</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Arrodoniment / xamfrà de dues línies amb fusió</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Arrodoniment / xamfrà de línia</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Utilitza sempre els atributs de la primera entitat</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>En fusionar dues línies, mantén automàticament els atributs de la primera entitat sense mostrar el diàleg de QGIS</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Arrodoniment / Xamfrà (Per lots)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panell d'arrodoniment i xamfrà per lots per a les entitats seleccionades</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Eina d'arrodoniment / xamfrà</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Eina per crear arrodoniments i xamfrans en geometries vectorials</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Arrodoniment i xamfrà</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Avís</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>La capa activa ha de ser una capa vectorial en mode d'edició.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informació</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>No hi ha entitats seleccionades per processar.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Arrodoniment per lots</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Xamfrà per lots</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Èxit</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>S'han processat {} entitats.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Especifiqueu la primera vora de la cantonada</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Especifiqueu la segona vora adjacent</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Restauració de cantonades (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Eina interactiva per restaurar cantonades punxegudes (elimina arrodoniments i xamfrans)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Per al processament per lots, la capa ha de ser editable i contenir entitats seleccionades</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Paràmetres d'arrodoniment / xamfrà</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Mode d'operació</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Arrodoniment (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Xamfrà (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Paràmetres d'arrodoniment</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>u.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Radi (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Nombre de segments d'arc:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Paràmetres de xamfrà</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Distància 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Distància 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Distàncies iguals (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Aplica a les entitats seleccionades</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Aplica l'arrodoniment o el xamfrà a tots els vèrtexs de les entitats seleccionades</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Arrodoniment</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Xamfrà</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Radi</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Bloqueja / desbloqueja el radi</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segments d'arrodoniment</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Distància 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Bloqueja / desbloqueja la distància 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Distància 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Bloqueja / desbloqueja la distància 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Distàncies enllaçades (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Distàncies independents (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Arrodoniment de vèrtex</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Xamfrà de vèrtex</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Restaura cantonada</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Gira</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Eina CAD interactiva de rotació de geometries amb selecció del punt pivot</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Especifiqueu el punt pivot</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Especifiqueu la direcció de referència</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Especifiqueu l'angle de rotació</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Angle:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Bloqueja l'angle / rotació interactiva</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Pas d'ajust:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Lliure</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Guarda una còpia</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Crea una còpia girada dels elements seleccionats, conservant l'original</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Rotació d'elements</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>Mirall CAD</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>Escalar i Girar CAD</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Eina CAD interactiva per escalar i girar geometries respecte a punts de referència</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Escala:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Bloquejar escala / càlcul lliure</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Feu clic al punt d'origen</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Feu clic al punt de referència</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Feu clic a l'escala i angle objectiu</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Crea una còpia escalada i girada dels elements seleccionats, deixant l'original intacte</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>Escalar i girar element(s) CAD</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Eina CAD interactiva per reflectir geometries respecte d'un eix de 2 punts</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Especifiqueu el primer punt de l'eix</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Especifiqueu el segon punt de l'eix</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Ajustament d'eix:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Orto)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Crea una còpia de mirall dels elements seleccionats mantenint l'original</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>Còpia de mirall CAD</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>Mirall CAD</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Angle d'eix:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Bloqueja l'angle d'eix / selecció interactiva</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Angle:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Especifiqueu la vora (seleccioneu el segment)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Especifiqueu el desplaçament o feu clic per confirmar</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD Desplaçament de vora (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Eina CAD interactiva per al desplaçament paral·lel d'un segment de vora de polígon o polilínia</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Bloqueja la distància / càlcul interactiu</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Distància:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Desplaçament de vora</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Estén (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Crea una nova entitat amb la vora desplaçada en lloc de modificar l'original</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Graó (Step)</translation>
        </message>
    </context>
</TS>
