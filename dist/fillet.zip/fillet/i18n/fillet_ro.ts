<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="ro">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Curățare noduri duplicate</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Curățare și reparare rapidă a nodurilor de geometrie duplicate</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Îmbină duplicatele din vârf (păstrează 1 nod)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Păstrează nodul #{0} (elimină #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Curăță toate duplicatele și erorile din element ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Curățare noduri duplicate</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Descurcă bucla de auto-intersecție</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Descurcare auto-intersecție</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Împărțire în geometrie multipartită</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Descurcă / păstrează corpul principal</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Împarte în {0} elemente separate</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Divizare în elemente separate</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Reparare automată a geometriei (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Reparare geometrie</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Curățare erori topologice</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Tipul de geometrie al stratului</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>Stratul curent nu acceptă geometrii multipartite (MultiPart).

Rezultatul reparării conține mai multe părți ({0}). Alegeți cum să salvați rezultatul:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Împarte în elemente SinglePart separate</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Păstrează ca MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Curățare geometrie (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Curățare rapidă a nodurilor duplicate și a erorilor</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Curățare și împărțire în elemente separate</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Specificați prima linie</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Specificați a doua linie</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Specificați raza sau faceți clic pentru a confirma</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Specificați teșitura sau faceți clic pentru a confirma</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Racordare / Teșire a două linii (Îmbinare)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Uniți două linii prin racordare sau teșire și îmbinați entitățile</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Racordare / teșire a două linii cu îmbinare</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Racordare / teșire linie</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Utilizează întotdeauna atributele primei entități</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>La îmbinarea a două linii, păstrează automat atributele primei entități fără a afișa dialogul QGIS</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Racordare / Teșire (În lot)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Panou de racordare și teșire în lot pentru entitățile selectate</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Instrument Racordare / Teșire</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Instrument pentru crearea de racordări și teșiri pe geometrii vectoriale</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Racordare &amp; Teșire</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Avertisment</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Stratul activ trebuie să fie un strat vectorial în modul de editare.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informații</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Nu există elemente selectate pentru procesare.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Racordare în lot</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Teșire în lot</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Succes</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>S-au procesat {} element(e).</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Specificați prima margine a colțului</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Specificați a doua margine adiacentă</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Restaurare colțuri (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Instrument interactiv pentru restaurarea colțurilor ascuțite (elimină racordările și teșirile)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Pentru procesarea în lot, stratul trebuie să fie editabil și să conțină elemente selectate</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Setări Racordare / Teșire</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Mod de operare</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Racordare (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Teșire (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Parametrii racordării</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>u.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Rază (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Număr segmente arc:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Parametrii teșirii</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Distanță 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Distanță 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Distanțe egale (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Aplică pe elementele selectate</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Aplică racordarea sau teșirea la toate nodurile elementelor selectate</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Racordare</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Teșire</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Rază</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Blocare / deblocare rază</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segmente racordare</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Distanță 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Blocare / deblocare distanță 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Distanță 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Blocare / deblocare distanță 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Distanțe corelate (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Distanțe independente (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Racordare nod</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Teșire nod</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Restaurare colț</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Rotire</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Instrument CAD interactiv de rotire a geometriilor cu selectarea punctului pivot</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Specificați punctul pivot</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Specificați direcția de referință</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Specificați unghiul de rotire</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Unghi:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Blocare unghi / rotire interactivă</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Pas de acroșare:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Liber</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Păstrează o copie</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creează o copie rotită a entităților selectate, păstrând originalul</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Rotire entitate/entități</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>Oglindire CAD</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>Scalare și Rotire CAD</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Instrument CAD interactiv pentru scalarea și rotirea geometriilor în raport cu punctele de referință</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Scară:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Blocare scară / calcul interactiv liber</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Faceți clic pe punctul de origine</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Faceți clic pe punctul de referință</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Faceți clic pe scara și unghiul țintă</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creează o copie scalată și rotită a elementelor selectate, lăsând originalul intact</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>Scalare și rotire entitate(ăți) CAD</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Instrument CAD interactiv pentru oglindirea geometriilor față de o axă de 2 puncte</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Specificați primul punct al axei</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Specificați al doilea punct al axei</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Acroșare axă:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Orto)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Creează o copie în oglindă a elementelor selectate, păstrând originalul</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>Copiere în oglindă CAD</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>Oglindire CAD</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Unghiul axei:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Blocare unghi axă / alegere interactivă</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Unghi:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Specificați muchia (selectați segmentul)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Specificați decalajul sau faceți clic pentru a confirma</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>Decalaj muchie CAD (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Instrument CAD interactiv pentru decalarea paralelă a unui segment de muchie de poligon sau polilinie</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Blocare distanță / calcul interactiv</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Distanță:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Decalaj muchie</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Extindere (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Creează o nouă entitate cu muchia decalată în loc de modificarea originalului</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Treaptă (Step)</translation>
        </message>
    </context>
</TS>
