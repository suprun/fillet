<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="hr">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Розбиття лінії (Explode)</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент розбиття ліній на окремі сегменти або складові частини (multipart)</source>
            <translation>Interactive CAD tool to split lines into individual segments or multipart components</translation>
        </message>
        <message>
            <source>CAD З'єднання ліній (Join)</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент топологічного з'єднання суміжних ліній у неперервні полілінії</source>
            <translation>Interactive CAD tool to topologically chain and join adjacent lines into continuous polylines</translation>
        </message>
        <message>
            <source>1. Оберіть лінію для розбиття на відрізки</source>
            <translation>1. Select a line to explode into segments</translation>
        </message>
        <message>
            <source>Зберегти як складену геометрію (multipart)</source>
            <translation>Save as multipart geometry</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single object (MultiLineString)</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного складеного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single multipart object (MultiLineString)</translation>
        </message>
        <message>
            <source>Шар є SinglePart (LineString) і не підтримує multipart</source>
            <translation>Layer is SinglePart (LineString) and does not support multipart</translation>
        </message>
        <message>
            <source>Розбити виділені лінії</source>
            <translation>Explode selected lines</translation>
        </message>
        <message>
            <source>Розбити виділені лінії ({})</source>
            <translation>Explode selected lines ({})</translation>
        </message>
        <message>
            <source>Розбиття ліній на складові частини (multipart)</source>
            <translation>Explode lines to multipart components</translation>
        </message>
        <message>
            <source>Розбиття ліній на окремі відрізки</source>
            <translation>Explode lines into separate segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків</source>
            <translation>Successfully exploded {} feature(s) into {} segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків (пропущено {} одинарних відрізків)</source>
            <translation>Successfully exploded {} feature(s) into {} segments (skipped {} single segment(s))</translation>
        </message>
        <message>
            <source>Об'єкт вже є простим відрізком (2 точки) і не може бути розділений</source>
            <translation>Feature is already a single segment (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>Усі виділені об'єкти вже є простими відрізками (2 точки) і не можуть бути розділені</source>
            <translation>All selected features are already single segments (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>CAD Explode Line</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>1. Оберіть першу лінію для з'єднання</source>
            <translation>1. Select first line to join</translation>
        </message>
        <message>
            <source>2. Оберіть суміжні лінії (Enter для фіксації)</source>
            <translation>2. Select adjacent lines (Enter to commit)</translation>
        </message>
        <message>
            <source>Допуск вузлів:</source>
            <translation>Node tolerance:</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії ({})</source>
            <translation>Join selected lines ({})</translation>
        </message>
        <message>
            <source>З'єднання ліній у полілінію</source>
            <translation>Join lines into polyline</translation>
        </message>
        <message>
            <source>З'єднання виділених ліній</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>CAD Join Lines</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} ліній в єдину полілінію</source>
            <translation>Successfully joined {} lines into a single polyline</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} виділених ліній в {} поліліній</source>
            <translation>Successfully joined {} selected lines into {} polylines</translation>
        </message>
        <message>
            <source>Кількість (Count):</source>
            <translation>Broj objekata:</translation>
        </message>
        <message>
            <source>Крок (Spacing):</source>
            <translation>Razmak:</translation>
        </message>
        <message>
            <source>Фіксована кількість нових копій об'єктів у масиві</source>
            <translation>Fiksni broj novih kopija objekata u nizu</translation>
        </message>
        <message>
            <source>Фіксована відстань (крок) між копіями об'єктів у масиві</source>
            <translation>Fiksna udaljenost (razmak) između kopija objekata u nizu</translation>
        </message>
        <message>
            <source>1. Вкажіть початкову точку / об'єкт</source>
            <translation>1. Kliknite početnu točku / objekt</translation>
        </message>
        <message>
            <source>2. Вкажіть кінцеву точку / крок</source>
            <translation>2. Kliknite krajnju točku / razmak</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів (Copy in Array)</source>
            <translation>CAD Niz objekata (Copy in Array)</translation>
        </message>
        <message>
            <source>Створення масиву копій виділених об'єктів уздовж напрямної лінії</source>
            <translation>Kopiranje objekata u nizu duž referentne linije</translation>
        </message>
        <message>
            <source>Параметри масиву (Feature Array)</source>
            <translation>Konfiguracija niza objekata</translation>
        </message>
        <message>
            <source>Режим:</source>
            <translation>Način:</translation>
        </message>
        <message>
            <source>Крок між об'єктами (од. карти):</source>
            <translation>Razmak između objekata (jedinice karte):</translation>
        </message>
        <message>
            <source>Кількість нових копій:</source>
            <translation>Broj novih objekata:</translation>
        </message>
        <message>
            <source>Кількість об'єктів (Feature Count)</source>
            <translation>Broj objekata</translation>
        </message>
        <message>
            <source>Крок / Відстань (Spacing)</source>
            <translation>Razmak</translation>
        </message>
        <message>
            <source>Крок і кількість (Spacing &amp; Count)</source>
            <translation>Razmak i broj objekata</translation>
        </message>
        <message>
            <source>CAD масив об'єктів</source>
            <translation>CAD niz objekata</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів</source>
            <translation>CAD Niz objekata</translation>
        </message>
        <message>
            <source>Очищення топології</source>
            <translation>Čišćenje topologije</translation>
        </message>
        <message>
            <source>Об'єкт успішно очищено та розділено на {0} окремих об'єктів.</source>
            <translation>Objekt je uspješno očišćen i podijeljen na {0} zasebnih objekata.</translation>
        </message>
        <message>
            <source>Успішно виправлено геометрію об'єкта (усунуто {0} помилок).</source>
            <translation>Geometrija objekta uspješno ispravljena (riješeno {0} pogrešaka).</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити {1})</source>
            <translation>Zadrži čvor #{0} (ukloni {1})</translation>
        </message>
        <message>
            <source>Злити всі {0} дублів у вершині (залишити 1 вузол)</source>
            <translation>Spoji svih {0} duplikata u vrhu (zadrži 1 čvor)</translation>
        </message>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD Očisti duplicirane čvorove</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>Brzo čišćenje i popravak dupliciranih čvorova geometrije</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>Spoji duplikate u vrhu (zadrži 1 čvor)</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>Zadrži čvor #{0} (ukloni #{1})</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>Očisti sve duplikate i pogreške u objektu ({0})</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>Čišćenje dupliciranih čvorova</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>Raspetljaj samopresijecajuću petlju</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>Raspetljavanje samopresijecanja</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>Razdijeli na višedijelnu geometriju</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>Raspetljaj / zadrži glavno tijelo</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>Razdijeli na {0} zasebnih objekata</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>Razdvajanje na zasebne objekte</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>Automatski popravi geometriju (Make Valid)</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>Popravak geometrije</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>Čišćenje topoloških pogrešaka</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>Vrsta geometrije sloja</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>Trenutni sloj ne podržava višedijelne geometrije (MultiPart).

Rezultat popravka sadrži više dijelova ({0}). Odaberite način spremanja:</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>Razdijeli na zasebne SinglePart objekte</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>Zadrži kao MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>Čišćenje geometrije (MultiPart)</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>Brzo čišćenje dupliciranih čvorova i pogrešaka</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>Očisti i razdijeli na zasebne objekte</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. Odredite prvu liniju</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. Odredite drugu liniju</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. Odredite polumjer ili kliknite za potvrdu</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. Odredite skošenje ili kliknite za potvrdu</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>Zaobljenje / Zakošenje dviju linija (Spoji)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>Spojite dvije linije zaobljenjem ili zakošenjem i spojite objekte</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>Zaobljenje / zakošenje dviju linija sa spajanjem</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>Zaobljenje / zakošenje linije</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>Uvijek koristi atribute prvog objekta</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>Pri spajanju dviju linija automatski zadrži atribute prvog objekta bez prikazivanja QGIS dijaloga</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>Zaobljenje / Zakošenje (Skupno)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>Ploča za skupno zaobljenje i zakošenje odabranih objekata</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>Alat za zaobljenje / zakošenje</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>Alat za izradu zaobljenja i zakošenja na vektorskim geometrijama</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>Zaobljenje i zakošenje</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>Upozorenje</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>Aktivni sloj mora biti vektorski sloj u načinu uređivanja.</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>Informacija</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>Nema odabranih objekata za obradu.</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>Skupno zaobljenje</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>Skupno zakošenje</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>Uspjeh</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>Obrađeno {} objekata.</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. Odredite prvi rub kuta</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. Odredite susjedni drugi rub</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>Vraćanje kutova (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>Interaktivni alat za vraćanje oštrih kutova (uklanja zaobljenja i zakošenja)</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>Za skupnu obradu sloj mora biti u načinu uređivanja i sadržavati odabrane objekte</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>Postavke zaobljenja / zakošenja</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>Način rada</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>Zaobljenje (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>Zakošenje (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>Parametri zaobljenja</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>jed.</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>Polumjer (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>Broj segmenata luka:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>Parametri zakošenja</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>Udaljenost 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>Udaljenost 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>Jednake udaljenosti (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>Primijeni na odabrane objekte</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>Primijeni zaobljenje ili zakošenje na sve prijelomne točke odabranih objekata</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>Zaobljenje</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>Zakošenje</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>Polumjer</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>Zaključaj / otključaj polumjer</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>Segmenti zaobljenja</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>Udaljenost 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>Zaključaj / otključaj udaljenost 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>Udaljenost 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>Zaključaj / otključaj udaljenost 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>Povezane udaljenosti (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>Odvojene udaljenosti (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>Zaobljenje točke</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>Zakošenje točke</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>Vrati kut</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD Rotiraj</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>Interaktivni CAD alat za rotaciju geometrija s odabirom točke rotacije</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. Odredite točku rotacije</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. Odredite referentni smjer</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. Odredite kut rotacije</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>Kut:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>Zaključaj kut / interaktivna rotacija</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>Korak privlačenja:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>Slobodno</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>Spremi kopiju</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Stvara rotiranu kopiju odabranih objekata zadržavajući izvornik</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD Rotacija objekata</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD Zrcaljenje</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD Mjerilo i Rotacija</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>Interaktivni CAD alat za promjenu mjerila i rotaciju geometrija u odnosu na referentne točke</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>Mjerilo:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>Zaključaj mjerilo / slobodan izračun</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. Kliknite na početnu točku</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. Kliknite na referentnu točku</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. Kliknite na ciljno mjerilo i kut</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Stvara skaliranu i rotiranu kopiju odabranih objekata, ostavljajući izvornik netaknutim</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD Skaliranje i rotacija objekata</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>Interaktivni CAD alat za zrcaljenje geometrija duž osi od 2 točke</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. Odredite prvu točku osi</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. Odredite drugu točku osi</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>Privlačenje osi:</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (Orto)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>Stvara zrcalnu kopiju odabranih objekata, zadržavajući original</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD Zrcalno kopiranje</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD Zrcaljenje</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>Kut osi:</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>Zaključaj kut osi / interaktivni odabir</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>Kut:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. Odredite rub (odaberite segment)</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. Odredite pomak ili kliknite za potvrdu</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD Pomak ruba (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>Interaktivni CAD alat za paralelni pomak segmenta ruba poligona ili polilinije</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>Zaključaj udaljenost / interaktivni izračun</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>Udaljenost:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>Pomak ruba</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>Produži (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>Stvara novi objekt s pomaknutim rubom umjesto promjene izvornika</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>Stuba (Step)</translation>
        </message>
    </context>
</TS>
