<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="zh_TW">
    <context>
        <name>FilletPlugin</name>
        <message>
            <source>CAD Полярний масив (Polar Array)</source>
            <translation>CAD 環狀陣列 (Polar Array)</translation>
        </message>
        <message>
            <source>Створення кругового (полярного) масиву копій виділених об'єктів навколо центру</source>
            <translation>繞中心建立所選圖徵複本的環狀（極向）陣列</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання / об'єкт</source>
            <translation>1. 指定旋轉中心 / 圖徵</translation>
        </message>
        <message>
            <source>2. Вкажіть кут / радіус масиву</source>
            <translation>2. 指定陣列角度 / 半徑</translation>
        </message>
        <message>
            <source>Фіксована кількість елементів у полярному масиві</source>
            <translation>環狀陣列中的固定項目數</translation>
        </message>
        <message>
            <source>Крок (Step angle):</source>
            <translation>步進角度 (Step angle):</translation>
        </message>
        <message>
            <source>Фіксований кутовий крок між елементами масиву</source>
            <translation>陣列項目之間的固定角度步長</translation>
        </message>
        <message>
            <source>Кут (Fill angle):</source>
            <translation>填滿角度 (Fill angle):</translation>
        </message>
        <message>
            <source>Загальний кут заповнення полярного масиву (360° = повне коло)</source>
            <translation>環狀陣列的總填滿角度（360° = 完整圓）</translation>
        </message>
        <message>
            <source>Обертати об'єкти (Rotate):</source>
            <translation>旋轉圖徵 (Rotate):</translation>
        </message>
        <message>
            <source>Якщо увімкнено, кожна копія повертається за рухом кола; якщо вимкнено — зберігає вихідний азимут</source>
            <translation>如果啟用，每個複本都會沿著圓形旋轉；如果停用，則保留原始方位角</translation>
        </message>
        <message>
            <source>CAD Polar Array Feature(s)</source>
            <translation>CAD 環狀圖徵陣列</translation>
        </message>
        <message>
            <source>CAD Розбиття лінії (Explode)</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент розбиття ліній на окремі сегменти або складові частини (multipart)</source>
            <translation>Interactive CAD tool to split lines into individual segments or multipart components</translation>
        </message>
        <message>
            <source>CAD З'єднання ліній (Join)</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент топологічного з'єднання суміжних ліній у неперервні полілінії</source>
            <translation>Interactive CAD tool to topologically chain and join adjacent lines into continuous polylines</translation>
        </message>
        <message>
            <source>1. Оберіть лінію для розбиття на відрізки</source>
            <translation>1. Select a line to explode into segments</translation>
        </message>
        <message>
            <source>Зберегти як складену геометрію (multipart)</source>
            <translation>Save as multipart geometry</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single object (MultiLineString)</translation>
        </message>
        <message>
            <source>Зберегти розбиті відрізки як частини єдиного складеного об'єкта (MultiLineString)</source>
            <translation>Save exploded segments as parts of a single multipart object (MultiLineString)</translation>
        </message>
        <message>
            <source>Шар є SinglePart (LineString) і не підтримує multipart</source>
            <translation>Layer is SinglePart (LineString) and does not support multipart</translation>
        </message>
        <message>
            <source>Розбити виділені лінії</source>
            <translation>Explode selected lines</translation>
        </message>
        <message>
            <source>Розбити виділені лінії ({})</source>
            <translation>Explode selected lines ({})</translation>
        </message>
        <message>
            <source>Розбиття ліній на складові частини (multipart)</source>
            <translation>Explode lines to multipart components</translation>
        </message>
        <message>
            <source>Розбиття ліній на окремі відрізки</source>
            <translation>Explode lines into separate segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків</source>
            <translation>Successfully exploded {} feature(s) into {} segments</translation>
        </message>
        <message>
            <source>Успішно розбито {} об'єктів на {} відрізків (пропущено {} одинарних відрізків)</source>
            <translation>Successfully exploded {} feature(s) into {} segments (skipped {} single segment(s))</translation>
        </message>
        <message>
            <source>Об'єкт вже є простим відрізком (2 точки) і не може бути розділений</source>
            <translation>Feature is already a single segment (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>Усі виділені об'єкти вже є простими відрізками (2 точки) і не можуть бути розділені</source>
            <translation>All selected features are already single segments (2 points) and cannot be exploded</translation>
        </message>
        <message>
            <source>CAD Explode Line</source>
            <translation>CAD Explode Line</translation>
        </message>
        <message>
            <source>1. Оберіть першу лінію для з'єднання</source>
            <translation>1. Select first line to join</translation>
        </message>
        <message>
            <source>2. Оберіть суміжні лінії (Enter для фіксації)</source>
            <translation>2. Select adjacent lines (Enter to commit)</translation>
        </message>
        <message>
            <source>Допуск вузлів:</source>
            <translation>Node tolerance:</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>З'єднати виділені лінії ({})</source>
            <translation>Join selected lines ({})</translation>
        </message>
        <message>
            <source>З'єднання ліній у полілінію</source>
            <translation>Join lines into polyline</translation>
        </message>
        <message>
            <source>З'єднання виділених ліній</source>
            <translation>Join selected lines</translation>
        </message>
        <message>
            <source>CAD Join Lines</source>
            <translation>CAD Join Lines</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} ліній в єдину полілінію</source>
            <translation>Successfully joined {} lines into a single polyline</translation>
        </message>
        <message>
            <source>Успішно з'єднано {} виділених ліній в {} поліліній</source>
            <translation>Successfully joined {} selected lines into {} polylines</translation>
        </message>
        <message>
            <source>Кількість (Count):</source>
            <translation>圖徵計數：</translation>
        </message>
        <message>
            <source>Крок (Spacing):</source>
            <translation>間距：</translation>
        </message>
        <message>
            <source>Фіксована кількість нових копій об'єктів у масиві</source>
            <translation>陣列中新圖徵複本的固定數量</translation>
        </message>
        <message>
            <source>Фіксована відстань (крок) між копіями об'єктів у масиві</source>
            <translation>陣列中圖徵複本之間的固定距離（間距）</translation>
        </message>
        <message>
            <source>1. Вкажіть початкову точку / об'єкт</source>
            <translation>1. 點擊起點 / 圖徵</translation>
        </message>
        <message>
            <source>2. Вкажіть кінцеву точку / крок</source>
            <translation>2. 點擊終點 / 間距</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів (Copy in Array)</source>
            <translation>CAD 圖徵陣列 (Copy in Array)</translation>
        </message>
        <message>
            <source>Створення масиву копій виділених об'єктів уздовж напрямної лінії</source>
            <translation>沿參考線按陣列複製圖徵</translation>
        </message>
        <message>
            <source>Параметри масиву (Feature Array)</source>
            <translation>圖徵陣列配置</translation>
        </message>
        <message>
            <source>Режим:</source>
            <translation>模式：</translation>
        </message>
        <message>
            <source>Крок між об'єктами (од. карти):</source>
            <translation>圖徵間距（地圖單位）：</translation>
        </message>
        <message>
            <source>Кількість нових копій:</source>
            <translation>新圖徵數量：</translation>
        </message>
        <message>
            <source>Кількість об'єктів (Feature Count)</source>
            <translation>圖徵計數</translation>
        </message>
        <message>
            <source>Крок / Відстань (Spacing)</source>
            <translation>間距</translation>
        </message>
        <message>
            <source>Крок і кількість (Spacing &amp; Count)</source>
            <translation>間距與圖徵計數</translation>
        </message>
        <message>
            <source>CAD масив об'єктів</source>
            <translation>CAD 圖徵陣列</translation>
        </message>
        <message>
            <source>CAD Масив об'єктів</source>
            <translation>CAD 圖徵陣列</translation>
        </message>
        <message>
            <source>Очищення топології</source>
            <translation>拓撲清理</translation>
        </message>
        <message>
            <source>Об'єкт успішно очищено та розділено на {0} окремих об'єктів.</source>
            <translation>要素已成功清理並拆分為 {0} 個獨立要素。</translation>
        </message>
        <message>
            <source>Успішно виправлено геометрію об'єкта (усунуто {0} помилок).</source>
            <translation>要素幾何已成功修復（已解決 {0} 個錯誤）。</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити {1})</source>
            <translation>保留節點 #{0} (刪除 {1})</translation>
        </message>
        <message>
            <source>Злити всі {0} дублів у вершині (залишити 1 вузол)</source>
            <translation>合併頂點處的所有 {0} 個重複項 (保留 1 個節點)</translation>
        </message>
        <message>
            <source>CAD Очищення дубльованих вузлів</source>
            <translation>CAD 清理重複節點</translation>
        </message>
        <message>
            <source>Швидке очищення та виправлення дубльованих вузлів геометрій</source>
            <translation>快速清理並修復重複幾何節點</translation>
        </message>
        <message>
            <source>Злити дублі у вершині (залишити 1 вузол)</source>
            <translation>合併頂點處的重複點（保留 1 個節點）</translation>
        </message>
        <message>
            <source>Залишити вузол #{0} (видалити #{1})</source>
            <translation>保留節點 #{0}（刪除 #{1}）</translation>
        </message>
        <message>
            <source>Очистити всі дублі та помилки в об'єкті ({0})</source>
            <translation>清理圖徵中的所有重複點和錯誤（{0}）</translation>
        </message>
        <message>
            <source>Очищення дубльованих вузлів</source>
            <translation>清理重複節點</translation>
        </message>
        <message>
            <source>Розплутати петлю самоперетину</source>
            <translation>解開自相交環</translation>
        </message>
        <message>
            <source>Розплутування самоперетину</source>
            <translation>解開自相交</translation>
        </message>
        <message>
            <source>Розбити на мультиполігон (MultiPart)</source>
            <translation>拆分為多部件幾何（MultiPart）</translation>
        </message>
        <message>
            <source>Розплутати / залишити основне тіло</source>
            <translation>解開 / 保留主體</translation>
        </message>
        <message>
            <source>Розділити на {0} окремих об'єктів</source>
            <translation>拆分為 {0} 個獨立圖徵</translation>
        </message>
        <message>
            <source>Розділення на окремі об'єкти</source>
            <translation>拆分為獨立圖徵</translation>
        </message>
        <message>
            <source>Автоматично виправити геометрію (Make Valid)</source>
            <translation>自動修復幾何（Make Valid）</translation>
        </message>
        <message>
            <source>Виправлення геометрії</source>
            <translation>修復幾何</translation>
        </message>
        <message>
            <source>Очищення топологічних помилок</source>
            <translation>清理拓撲錯誤</translation>
        </message>
        <message>
            <source>Тип геометрії шару</source>
            <translation>圖層幾何類型</translation>
        </message>
        <message>
            <source>Поточний шар не підтримує багаточастинні геометрії (MultiPart).

Результат виправлення містить декілька частин ({0}). Оберіть варіант збереження:</source>
            <translation>目前圖層不支援多部件幾何（MultiPart）。

修復結果包含多個部件 ({0})。請選擇儲存方式：</translation>
        </message>
        <message>
            <source>Розбити на окремі SinglePart об'єкти</source>
            <translation>拆分為獨立的 SinglePart 圖徵</translation>
        </message>
        <message>
            <source>Залишити як MultiPart</source>
            <translation>保留為 MultiPart</translation>
        </message>
        <message>
            <source>Очищення геометрії (MultiPart)</source>
            <translation>清理幾何（MultiPart）</translation>
        </message>
        <message>
            <source>Швидке очищення дубльованих вузлів та помилок</source>
            <translation>快速清理重複節點和錯誤</translation>
        </message>
        <message>
            <source>Очищення та розбиття на окремі об'єкти</source>
            <translation>清理並拆分為獨立圖徵</translation>
        </message>
        <message>
            <source>1. Вкажіть першу лінію</source>
            <translation>1. 指定第一條線</translation>
        </message>
        <message>
            <source>2. Вкажіть другу лінію</source>
            <translation>2. 指定第二條線</translation>
        </message>
        <message>
            <source>3. Вкажіть радіус або клікніть для підтвердження</source>
            <translation>3. 指定半徑或按一下以確認</translation>
        </message>
        <message>
            <source>3. Вкажіть фаску або клікніть для підтвердження</source>
            <translation>3. 指定倒角或按一下以確認</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній (Merge)</source>
            <translation>雙線圓角 / 倒角 (合併)</translation>
        </message>
        <message>
            <source>З'єднання двох ліній скругленням або фаскою з об'єднанням об'єктів</source>
            <translation>透過圓角或倒角連接兩條線並合併圖徵</translation>
        </message>
        <message>
            <source>Скруглення / фаска двох ліній з об'єднанням</source>
            <translation>雙線圓角 / 倒角並合併</translation>
        </message>
        <message>
            <source>Скруглення / фаска лінії</source>
            <translation>線圓角 / 倒角</translation>
        </message>
        <message>
            <source>Завжди використовувати атрибути першого об'єкта</source>
            <translation>始終使用第一個圖徵的屬性</translation>
        </message>
        <message>
            <source>При об'єднанні двох ліній автоматично зберігати атрибути першого об'єкта без показу діалогу QGIS</source>
            <translation>合併兩條線時，自動保留第一個圖徵的屬性而不顯示 QGIS 對話方塊</translation>
        </message>
        <message>
            <source>Fillet / Chamfer (Пакетна обробка)</source>
            <translation>圓角 / 倒角 (批次處理)</translation>
        </message>
        <message>
            <source>Панель пакетного скруглення (Fillet) та фаски (Chamfer) для виділених об'єктів</source>
            <translation>選取圖徵的批次圓角與倒角面板</translation>
        </message>
        <message>
            <source>Інструмент Fillet / Chamfer</source>
            <translation>圓角 / 倒角工具</translation>
        </message>
        <message>
            <source>Інструмент для створення скруглень (Fillet) та фасок (Chamfer)</source>
            <translation>在向量圖層幾何體上建立圓角與倒角的工具</translation>
        </message>
        <message>
            <source>Fillet &amp; Chamfer</source>
            <translation>圓角與倒角</translation>
        </message>
        <message>
            <source>Увага</source>
            <translation>警告</translation>
        </message>
        <message>
            <source>Активний шар повинен бути векторним і перебувати в режимі редагування.</source>
            <translation>使用中圖層必須是處於編輯模式的向量圖層。</translation>
        </message>
        <message>
            <source>Інфо</source>
            <translation>資訊</translation>
        </message>
        <message>
            <source>Немає виділених об'єктів для обробки.</source>
            <translation>沒有選取的圖徵可供處理。</translation>
        </message>
        <message>
            <source>Пакетне скруглення</source>
            <translation>批次圓角</translation>
        </message>
        <message>
            <source>Пакетна фаска</source>
            <translation>批次倒角</translation>
        </message>
        <message>
            <source>Успіх</source>
            <translation>成功</translation>
        </message>
        <message>
            <source>Оброблено {} об'єкт(ів).</source>
            <translation>已處理 {} 個圖徵。</translation>
        </message>
        <message>
            <source>1. Вкажіть перше ребро кута</source>
            <translation>1. 指定第一條角邊</translation>
        </message>
        <message>
            <source>2. Вкажіть суміжне друге ребро</source>
            <translation>2. 指定相鄰的第二條邊</translation>
        </message>
        <message>
            <source>Відновлення кутів (Unfillet / Unchamfer)</source>
            <translation>恢復尖角 (Unfillet / Unchamfer)</translation>
        </message>
        <message>
            <source>Інструмент відновлення гострих кутів (видалення скруглень та фасок)</source>
            <translation>恢復尖角的互動式工具（移除圓角和倒角）</translation>
        </message>
        <message>
            <source>Для пакетної обробки шар має бути у режимі редагування та містити виділені об'єкти</source>
            <translation>批次處理需要圖層處於可編輯狀態並包含選取的圖徵</translation>
        </message>
        <message>
            <source>Параметри Fillet / Chamfer</source>
            <translation>圓角 / 倒角設定</translation>
        </message>
        <message>
            <source>Режим операції</source>
            <translation>操作模式</translation>
        </message>
        <message>
            <source>Скруглення (Fillet)</source>
            <translation>圓角 (Fillet)</translation>
        </message>
        <message>
            <source>Фаска (Chamfer)</source>
            <translation>倒角 (Chamfer)</translation>
        </message>
        <message>
            <source>Параметри скруглення</source>
            <translation>圓角參數</translation>
        </message>
        <message>
            <source>од.</source>
            <translation>單位</translation>
        </message>
        <message>
            <source>Радіус (R):</source>
            <translation>半徑 (R):</translation>
        </message>
        <message>
            <source>Кількість сегментів дуги:</source>
            <translation>圓弧線段數:</translation>
        </message>
        <message>
            <source>Параметри фаски</source>
            <translation>倒角參數</translation>
        </message>
        <message>
            <source>Відстань 1 (d1):</source>
            <translation>距離 1 (d1):</translation>
        </message>
        <message>
            <source>Відстань 2 (d2):</source>
            <translation>距離 2 (d2):</translation>
        </message>
        <message>
            <source>Однакові відстані (d1 = d2)</source>
            <translation>等距 (d1 = d2)</translation>
        </message>
        <message>
            <source>Застосувати до виділених об'єктів</source>
            <translation>套用到選取的圖徵</translation>
        </message>
        <message>
            <source>Застосувати скруглення або фаску до всіх вершин виділених об'єктів</source>
            <translation>將圓角或倒角套用到選取圖徵的所有頂點</translation>
        </message>
        <message>
            <source>Fillet</source>
            <translation>圓角</translation>
        </message>
        <message>
            <source>Chamfer</source>
            <translation>倒角</translation>
        </message>
        <message>
            <source>Radius</source>
            <translation>半徑</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати радіус</source>
            <translation>鎖定 / 解鎖半徑</translation>
        </message>
        <message>
            <source>Fillet segments</source>
            <translation>圓角線段數</translation>
        </message>
        <message>
            <source>Distance 1</source>
            <translation>距離 1</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 1</source>
            <translation>鎖定 / 解鎖距離 1</translation>
        </message>
        <message>
            <source>Distance 2</source>
            <translation>距離 2</translation>
        </message>
        <message>
            <source>Блокувати / розблокувати відстань 2</source>
            <translation>鎖定 / 解鎖距離 2</translation>
        </message>
        <message>
            <source>Відстані зв'язані (d1 = d2)</source>
            <translation>距離已連結 (d1 = d2)</translation>
        </message>
        <message>
            <source>Відстані роздільні (d1 ≠ d2)</source>
            <translation>距離獨立 (d1 ≠ d2)</translation>
        </message>
        <message>
            <source>Скруглення вершини</source>
            <translation>頂點圓角</translation>
        </message>
        <message>
            <source>Фаска вершини</source>
            <translation>頂點倒角</translation>
        </message>
        <message>
            <source>Відновлення кута</source>
            <translation>恢復尖角</translation>
        </message>
        <message>
            <source>CAD Обертання (Rotate)</source>
            <translation>CAD 旋轉</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент обертання геометрій із вибором центру (Pivot)</source>
            <translation>具有旋轉中心選擇功能的互動式 CAD 幾何旋轉工具</translation>
        </message>
        <message>
            <source>1. Вкажіть центр обертання</source>
            <translation>1. 指定旋轉中心</translation>
        </message>
        <message>
            <source>2. Вкажіть базовий орієнтир</source>
            <translation>2. 指定基準參考方向</translation>
        </message>
        <message>
            <source>3. Вкажіть цільовий кут</source>
            <translation>3. 指定旋轉角度</translation>
        </message>
        <message>
            <source>Кут (Angle):</source>
            <translation>角度:</translation>
        </message>
        <message>
            <source>Блокувати кут / інтерактивне обертання</source>
            <translation>鎖定角度 / 互動式旋轉</translation>
        </message>
        <message>
            <source>Крок кута:</source>
            <translation>貼齊步長:</translation>
        </message>
        <message>
            <source>Вільний (Free)</source>
            <translation>自由</translation>
        </message>
        <message>
            <source>Зберегти копію (Copy)</source>
            <translation>保留副本 (複製)</translation>
        </message>
        <message>
            <source>Створює повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>建立所選圖徵的旋轉複本，同時保留原始圖徵</translation>
        </message>
        <message>
            <source>CAD Rotate Feature(s)</source>
            <translation>CAD 旋轉圖徵</translation>
        </message>
        <message>
            <source>CAD Дзеркало (Mirror)</source>
            <translation>CAD 鏡像</translation>
        </message>
        <message>
            <source>CAD Масштаб та Обертання (Scale &amp; Rotate)</source>
            <translation>CAD 縮放與旋轉</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент масштабування та обертання геометрій відносно опорних точок</source>
            <translation>用於相對於參考點縮放和旋轉幾何圖形的互動式 CAD 工具</translation>
        </message>
        <message>
            <source>Масштаб (Scale):</source>
            <translation>比例:</translation>
        </message>
        <message>
            <source>Блокувати масштаб / вільний розрахунок</source>
            <translation>鎖定比例 / 自由互動計算</translation>
        </message>
        <message>
            <source>1. Вкажіть центр масштабування</source>
            <translation>1. 點擊原點/旋轉中心</translation>
        </message>
        <message>
            <source>2. Вкажіть базову точку (Ref)</source>
            <translation>2. 點擊基準參考點</translation>
        </message>
        <message>
            <source>3. Вкажіть цільове положення</source>
            <translation>3. 點擊目標縮放與角度</translation>
        </message>
        <message>
            <source>Створює масштабовану та повернуту копію виділених об'єктів, залишаючи оригінал</source>
            <translation>建立所選圖徵的縮放和旋轉副本，同時保留原始圖徵</translation>
        </message>
        <message>
            <source>CAD Scale &amp; Rotate Feature(s)</source>
            <translation>CAD 縮放與旋轉圖徵</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент дзеркального відображення геометрій відносно осі з 2 точок</source>
            <translation>基於2點軸線進行幾何鏡像的互動式 CAD 工具</translation>
        </message>
        <message>
            <source>1. Вкажіть першу точку осі</source>
            <translation>1. 指定軸線的第一個點</translation>
        </message>
        <message>
            <source>2. Вкажіть другу точку осі</source>
            <translation>2. 指定軸線的第二個點</translation>
        </message>
        <message>
            <source>Прив'язка осі:</source>
            <translation>軸線貼齊：</translation>
        </message>
        <message>
            <source>90° (Орто)</source>
            <translation>90° (正交)</translation>
        </message>
        <message>
            <source>Створює дзеркальну копію виділених об'єктів, залишаючи оригінал</source>
            <translation>建立所選圖徵的鏡像複本並保留原始圖徵</translation>
        </message>
        <message>
            <source>CAD Дзеркальне копіювання</source>
            <translation>CAD 鏡像複製</translation>
        </message>
        <message>
            <source>CAD Дзеркальне відображення</source>
            <translation>CAD 鏡像</translation>
        </message>
        <message>
            <source>Кут осі:</source>
            <translation>軸線角度：</translation>
        </message>
        <message>
            <source>Блокувати кут осі / інтерактивне обрання</source>
            <translation>鎖定軸線角度 / 互動選擇</translation>
        </message>
        <message>
            <source>Кут:</source>
            <translation>角度:</translation>
        </message>
        <message>
            <source>1. Вкажіть ребро (оберіть відрізок)</source>
            <translation>1. 指定邊緣（選擇線段）</translation>
        </message>
        <message>
            <source>2. Вкажіть зміщення або клікніть для підтвердження</source>
            <translation>2. 指定偏移或按一下以確認</translation>
        </message>
        <message>
            <source>CAD Зсув ребра (Edge Offset)</source>
            <translation>CAD 邊緣偏移 (Edge Offset)</translation>
        </message>
        <message>
            <source>Інтерактивний CAD інструмент паралельного зсуву відрізка полігона чи полілінії</source>
            <translation>用於多邊形或折線線段平行偏移的互動式 CAD 工具</translation>
        </message>
        <message>
            <source>Блокувати відстань / вільний розрахунок</source>
            <translation>鎖定距離 / 互動式計算</translation>
        </message>
        <message>
            <source>Відстань:</source>
            <translation>距離:</translation>
        </message>
        <message>
            <source>Зсув ребра</source>
            <translation>邊緣偏移</translation>
        </message>
        <message>
            <source>Подовження (Extend)</source>
            <translation>延伸 (Extend)</translation>
        </message>
        <message>
            <source>Створити новий об'єкт зі зміщеним ребром замість модифікації оригінального</source>
            <translation>建立具有偏移邊緣的新圖徵而非修改原始圖徵</translation>
        </message>
        <message>
            <source>Сходинка (Step)</source>
            <translation>階梯 (Step)</translation>
        </message>
    </context>
</TS>
