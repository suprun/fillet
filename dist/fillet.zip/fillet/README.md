<div align="center">

# Fillet & Chamfer for QGIS 3.x (Interactive & Batch)

<p align="center">
  <img src="icon.png" alt="Fillet & Chamfer Logo" width="96" height="96" />
</p>

**Comprehensive CAD editing suite for QGIS: Interactive Fillet (corner rounding), Chamfer (corner beveling), and Two-Edge Corner Restoration (Unfillet / Unchamfer), plus instant Batch Fillet & Chamfer Processing for QGIS 3.x & 4.x.**

[![QGIS Compatibility](https://img.shields.io/badge/QGIS-3.16%20--%204.99-brightgreen.svg?logo=qgis)](https://plugins.qgis.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.9%20%7C%203.12-blue.svg?logo=python)](https://python.org)
[![PyQt](https://img.shields.io/badge/UI-PyQt5%20%7C%20PyQt6-orange.svg?logo=qt)](https://riverbankcomputing.com/software/pyqt/)
[![Multi-Version Tests](https://img.shields.io/badge/Tests-5%20QGIS%20Versions%20Passed-success.svg)](#multi-version-testing)
[![Languages](https://img.shields.io/badge/Languages-40%20Locales-blueviolet.svg)](#localization)

</div>

---

## 🌟 Overview

The **Fillet & Chamfer for QGIS 3.x** plugin brings a complete suite of CAD-grade corner and rotation editing tools into QGIS:

1. **Interactive Fillet & Chamfer CAD Tool (QGIS 3.x)**: Backports the interactive digitizing workflow introduced in QGIS 4.0 directly into the **QGIS 3.x LTR series** (from QGIS 3.16 to 3.44+), complete with an on-canvas CAD HUD widget.
2. **Interactive Corner Restoration Tool / Unfillet & Unchamfer (QGIS 3.x & QGIS 4.x)**: A dedicated CAD Two-Edge selection tool allowing you to select two adjacent straight edges, remove intermediate arc chords or bevel segments, and reconstruct the exact sharp intersection corner ($V_{\text{sharp}}$).
3. **Interactive CAD 3-Point Rotation Tool (QGIS 3.x & QGIS 4.x)**: Precision 3-point CAD geometry rotation (Pivot Center $\rightarrow$ Reference Baseline $\rightarrow$ Target Angle / Direction) with full native QGIS snapping, floating CAD HUD, angle locking, angle snap stepping (15°, 45°, 90°), and duplicate copy mode.
4. **Batch Processing Dock Panel (QGIS 3.x & QGIS 4.x)**: A dedicated dock widget to round or bevel all vertices across selected features and complex polygon rings with a single click.

---

## 🚀 Key Features

### 1. 🎯 Interactive Fillet & Chamfer Digitizing Tool (QGIS 3.x)
- **On-Canvas CAD HUD Control**: Floating panel on the map canvas providing instant control over radius, distances, and arc segments count.
- **Fillet Mode (Corner Rounding)**:
  - Precise circular arc discretization with customizable **Fillet segments** count ($N$ segments = $N+1$ vertices).
  - Clean analytical interpolation ensuring exact tangent intersection with adjacent edges.
- **Chamfer Mode (Corner Beveling)**:
  - Symmetric beveling ($d_1 = d_2$) or independent dual-distance beveling ($d_1 \neq d_2$) with link toggle.
- **Lock / Unlock Numeric Mode**:
  - **Locked (Default)**: Click any vertex to instantly apply the exact configured numeric value.
  - **Unlocked**: Move the mouse interactively across the canvas to adjust the radius or distance dynamically in real time.
- **Visual Feedback & Live Snapping**:
  - Tangent snap markers on adjacent segments.
  - Live dashed rubberband preview of the resulting fillet arc or chamfer segment.
- **Full CRS & Units Adaptation**:
  - Automatic dynamic adaptation for **Projected CRS** (meters: 3 decimal places, step 1.0, default 5.0m) and **Geographic CRS** (degrees / EPSG:4326: 6 decimal places, step 0.00005°, default 0.0001°).

---

### 2. 📐 Interactive Corner Restoration / Unfillet & Unchamfer (QGIS 3.x & QGIS 4.x)
- **CAD Two-Edge Selection Workflow**:
  - **Step 1**: Hover over any straight edge $E_1$ adjacent to the corner (highlighted in amber) and left-click to select.
  - **Step 2**: Hover over the second adjacent straight edge $E_2$. The tool computes the infinite ray intersection $V_{\text{sharp}}$, automatically detects all intermediate arc chords or bevel segments, and renders a live rubberband preview of the reconstructed geometry.
  - **Step 3**: Left-click $E_2$ to commit the sharp corner reconstruction into the layer edit history.
  - Right-click or press `Escape` at any time to cancel edge selection.
- **Handles Any Arc Complexity**:
  - Accurately reconstructs corners regardless of arc discretization density (e.g., 2, 8, 16, 64 chords) and handles polygon closure vertices seamlessly.
- **Dedicated Toolbar Action**:
  - Integrated into the *Advanced Digitizing Toolbar* with a custom icon featuring the standard QGIS delete badge.

---

### 3. 🔄 Interactive CAD 3-Point Rotation Tool (QGIS 3.x & QGIS 4.x)
- **3-Point CAD Workflow**:
  - **Point 1 (Pivot Center $P_{\text{center}}$)**: Click anywhere on the map or snap to existing vertices/edges/intersections.
  - **Point 2 (Reference Direction $P_{\text{ref}}$)**: Click to establish the baseline ray orientation.
  - **Point 3 (Target Angle / Direction)**: Move the mouse to rotate interactively or enter the exact numeric angle in the floating HUD. Click or press `Enter` to commit.
- **Floating CAD HUD & Advanced Controls**:
  - Numeric angle input with strict digit-only validator and decimal separator normalization.
  - Angle locking toggle for applying fixed rotation angles instantly.
  - Discrete angle snap stepping (`Free`, `5°`, `15°`, `45°`, `90°`) and `Shift` key shortcut.
  - **Save Copy Mode**: Rotate a copy while keeping the original geometry intact.
- **Full Snapping Integration**:
  - Uses native QGIS `QgsSnappingUtils` and displays `QgsSnapIndicator` matching project snap settings.

---

### 4. ⚡ Batch Processing Dock Panel (QGIS 3.x & QGIS 4.x)
- Dockable panel in the main window for rapid batch processing.
- Automatically processes all vertices of all parts in selected features (`LineString`, `Polygon`, `MultiLineString`, `MultiPolygon`).
- Supports exterior rings as well as all interior hole rings.
- **Batch Fillet**: Rounds all corners across selected features with the specified radius and segment count.
- **Batch Chamfer**: Bevels all corners across selected features with the specified distances.

---

### 5. 🛡️ Edit-Mode Safety & Native Transactions
- All toolbar action buttons and tools are **automatically enabled only when an active vector layer is in Edit Mode** (`layer.isEditable() == True`).
- If editing is toggled off while a tool is active, the tool automatically unsets and closes on-canvas widgets to prevent unintended changes.
- Full native Undo/Redo (`Ctrl+Z` / `Ctrl+Y`) transaction support for all interactive and batch operations.

---

## 📦 Compatibility Matrix

| QGIS Version | Platform | UI Framework | Fillet & Chamfer Tool | Corner Restore Tool | CAD Rotation Tool | Batch Dock Widget | Test Status |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **QGIS 3.16 LTR** | Windows / Linux / macOS | Qt5 / PyQt5 | ✅ Included | ✅ Included | ✅ Included | ✅ Included | ✅ Passed |
| **QGIS 3.28 LTR** | Windows / Linux / macOS | Qt5 / PyQt5 | ✅ Included | ✅ Included | ✅ Included | ✅ Included | ✅ Passed |
| **QGIS 3.34 LTR** | Windows / Linux / macOS | Qt5 / PyQt5 | ✅ Included | ✅ Included | ✅ Included | ✅ Included | ✅ Passed |
| **QGIS 3.40 LTR** | Windows / Linux / macOS | Qt5 / PyQt5 | ✅ Included | ✅ Included | ✅ Included | ✅ Included | ✅ Passed |
| **QGIS 4.0.x** | Windows / Linux / macOS | Qt6 / PyQt6 | *Native QGIS 4 tool* | ✅ Included | ✅ Included | ✅ Included | ✅ Passed |

---

## 📥 Installation

### Method 1: Official QGIS Plugin Repository
1. Open QGIS.
2. Go to **Plugins** → **Manage and Install Plugins...**
3. Search for **Fillet & Chamfer**.
4. Click **Install Plugin**.

### Method 2: Custom Plugin Repository
1. In QGIS, open **Plugins** → **Manage and Install Plugins...** → **Settings**.
2. Under *Plugin Repositories*, click **Add...**.
3. Set Name: `Suprun QGIS Plugins`
4. Set URL: `https://raw.githubusercontent.com/suprun/fillet/master/dist/plugins.xml`
5. Click **OK**, then install the plugin.

### Method 3: Manual Installation (from ZIP)
1. Download `fillet.zip` from [Latest Releases](https://github.com/suprun/fillet/releases/latest).
2. Unzip into your QGIS active profile plugin directory:
   - **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\fillet`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/fillet`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/fillet`
3. Restart QGIS or activate the plugin in the **Plugins Manager**.

---

## 📖 Usage Guide

### 🛠️ 1. Interactive Fillet / Chamfer (QGIS 3.x)
1. Select a Line or Polygon vector layer in the Layers panel.
2. Click **Toggle Editing** (`Ctrl+E` or pencil icon).
3. Click the **Fillet / Chamfer Tool** button on the *Advanced Digitizing Toolbar* or in the *Vector* menu.
4. The floating CAD HUD control appears on the canvas:
   - Choose **Fillet** (enter Radius $R$ and number of Arc Segments) or **Chamfer** (enter Distance $d_1$ and $d_2$).
   - Toggle the **Lock Icon** (locked to click-apply fixed value; unlocked to drag interactively).
5. Hover over any vertex of the feature to view tangent cut markers and live preview.
6. Left-click to commit the fillet or chamfer.

### 📐 2. Interactive Corner Restoration / Unfillet & Unchamfer (QGIS 3.x & QGIS 4.x)
1. Put your target layer into edit mode.
2. Click the **Corner Restore Tool** button on the *Advanced Digitizing Toolbar*.
3. Click the first straight edge $E_1$ adjacent to the rounded or beveled corner.
4. Hover over the second adjacent straight edge $E_2$ to see the intersection preview and reconstructed sharp corner.
5. Click the second edge $E_2$ to commit the corner reconstruction. Right-click or press `Escape` to cancel.

### 🔄 3. Interactive CAD 3-Point Rotation (QGIS 3.x & QGIS 4.x)
1. Put your target layer into edit mode and select the features you wish to rotate.
2. Click the **CAD Rotate Tool** button on the *Advanced Digitizing Toolbar*.
3. **Step 1 (Pivot)**: Click on the canvas (or snap to any vertex/edge) to set the rotation center pivot $P_{\text{center}}$.
4. **Step 2 (Reference)**: Click to set the reference baseline direction $P_{\text{ref}}$.
5. **Step 3 (Angle / Target)**: Move the mouse to rotate interactively, or type the exact angle in the floating HUD. Click or press `Enter` to commit the rotation.
   - Check **Save copy (Copy)** in the HUD if you want to duplicate rotated features.
   - Use the **Snap step** selector (`5°`, `15°`, `45°`, `90°`) or hold `Shift` to constrain the angle.

### ⚡ 4. Batch Processing Panel (QGIS 3.x & QGIS 4.x)
1. Put your target layer into edit mode.
2. Select one or more features using the QGIS selection tool.
3. Click the **Fillet / Chamfer (Batch Processing)** button to open the dock panel.
4. Choose **Fillet** or **Chamfer** and configure your parameters.
5. Click **Apply to Selected Features**. All corners of the selected features will be rounded or beveled immediately.

---

## 🧪 Development & Multi-Version Testing

The plugin includes an automated test suite covering geometry precision, plugin lifecycle, translation loading, and settings persistence.

To run automated smoke tests across all installed QGIS versions on your machine:

```powershell
python scripts/smoke_test_all_qgis.py
```

### Packaging for Release
To package a clean, repository-compliant release ZIP without test caches or ignored files:

```powershell
python scripts/package_plugin.py
```

---

## 🌐 Localization

The plugin is fully translated into **40 locales (all official QGIS GUI languages)**:
- Arabic (`ar`), Bulgarian (`bg`), Catalan (`ca`), Czech (`cs`), Danish (`da`), German (`de`), Greek (`el`), English (`en`), Spanish (`es`), Estonian (`et`), Basque (`eu`), Finnish (`fi`), French (`fr`), Galician (`gl`), Hindi (`hi`), Croatian (`hr`), Hungarian (`hu`), Indonesian (`id`), Italian (`it`), Japanese (`ja`), Korean (`ko`), Lithuanian (`lt`), Latvian (`lv`), Norwegian (`nb`), Dutch (`nl`), Polish (`pl`), Portuguese (`pt`, `pt_BR`), Romanian (`ro`), Slovak (`sk`), Slovenian (`sl`), Serbian (`sr`), Swedish (`sv`), Thai (`th`), Turkish (`tr`), Ukrainian (`uk`), Vietnamese (`vi`), Chinese (`zh`, `zh_CN`, `zh_TW`).

Translations are automatically compiled from `.ts` to `.qm` via:
```powershell
python scripts/compile_translations.py
```

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## 👤 Author

**Serhiy Suprun**
- GitHub: [@suprun](https://github.com/suprun)
- Email: `suprun.serhiy+qgis@gmail.com`
- Issues & Suggestions: [GitHub Issues](https://github.com/suprun/fillet/issues)
